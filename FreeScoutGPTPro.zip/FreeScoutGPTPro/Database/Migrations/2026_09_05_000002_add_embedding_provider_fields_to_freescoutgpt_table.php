<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddEmbeddingProviderFieldsToFreescoutgptTable extends Migration
{
    public function up()
    {
        Schema::table('freescoutgpt', function (Blueprint $table) {
            if (!Schema::hasColumn('freescoutgpt', 'llm_embedding_provider_url')) {
                $table->string('llm_embedding_provider_url')->nullable()->after('llm_gateway_embedding_model');
            }
            if (!Schema::hasColumn('freescoutgpt', 'llm_embedding_api_key')) {
                $table->string('llm_embedding_api_key')->nullable()->after('llm_embedding_provider_url');
            }
        });
    }

    public function down()
    {
        Schema::table('freescoutgpt', function (Blueprint $table) {
            if (Schema::hasColumn('freescoutgpt', 'llm_embedding_provider_url')) {
                $table->dropColumn('llm_embedding_provider_url');
            }
            if (Schema::hasColumn('freescoutgpt', 'llm_embedding_api_key')) {
                $table->dropColumn('llm_embedding_api_key');
            }
        });
    }
}
