<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddLlmGatewayProviderToFreescoutgptTable extends Migration
{
    public function up()
    {
        Schema::table('freescoutgpt', function (Blueprint $table) {
            if (!Schema::hasColumn('freescoutgpt', 'llm_gateway_provider')) {
                $table->string('llm_gateway_provider')->nullable()->after('llm_gateway_enabled');
            }
        });
    }

    public function down()
    {
        Schema::table('freescoutgpt', function (Blueprint $table) {
            if (Schema::hasColumn('freescoutgpt', 'llm_gateway_provider')) {
                $table->dropColumn('llm_gateway_provider');
            }
        });
    }
}
