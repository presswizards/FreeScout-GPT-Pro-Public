document.addEventListener("DOMContentLoaded", function () {
    const settingsRoot = document.getElementById('freescout-gpt-pro-container');
    const mailboxId = settingsRoot?.dataset.mailboxId;
    const providerSettings = {
        gatewayProviderCustomLabel: settingsRoot?.dataset.gatewayProviderCustomLabel || 'Custom',
        refreshProvidersLabel: settingsRoot?.dataset.refreshProvidersLabel || 'Refresh Providers',
        refreshingProvidersLabel: settingsRoot?.dataset.refreshingProvidersLabel || 'Refreshing...',
        providerRegistryFetchWarning: settingsRoot?.dataset.providerRegistryFetchWarning || 'Unable to contact the provider registry. Using the bundled fallback list.'
    };
    const providerRegistry = (() => {
        const rawValue = settingsRoot?.dataset.providerRegistry || '';
        try {
            const decodedValue = rawValue ? atob(rawValue) : '[]';
            const parsed = JSON.parse(decodedValue);
            return Array.isArray(parsed) ? parsed : [];
        } catch (error) {
            return [];
        }
    })();
    const providerRegistryWarning = settingsRoot?.dataset.providerRegistryWarning || '';
    const currentPath = window.location.pathname || '';
    const appBasePath = currentPath.includes('/mailbox/') ? currentPath.split('/mailbox/')[0] : '';
    const buildAppUrl = (path) => {
        const normalizedPath = path.startsWith('/') ? path : `/${path}`;
        return `${appBasePath}${normalizedPath}`;
    };
    const robotIcons = document.querySelectorAll('i.fa-solid.fa-robot');
    robotIcons.forEach(icon => {
        icon.classList.add('fa-fade');
        setTimeout(() => {
            icon.classList.remove('fa-fade');
        }, 3000);
    });

    const handler = new FS.Checkout({
        product_id: '19065',
        plan_id: '31580',
        public_key: 'pk_25feb8abb0fabc990c5ab3d30a94e',
    });

    const lastCheckKey = `gptpro_license_check_${mailboxId}`;
    const lastCheck = localStorage.getItem(lastCheckKey);
    const now = Date.now();
    if (!lastCheck || now - parseInt(lastCheck, 10) > 24 * 60 * 60 * 1000) {
        if (typeof handleLicenseValidation === 'function') {
            handleLicenseValidation();
            localStorage.setItem(lastCheckKey, now.toString());
        }
    }

    function openFreemiusCheckout(trial = false) {
        handler.open({
            licenses: 1,
            // billing_cycle: 'annual',
            billing_cycle_selector: 'responsive_list',
            show_reviews: true,
            trial, // trial: true or false
            purchaseCompleted: (response) => {
                console.log('Purchase completed:', response);
                handleLicenseValidation(null, response.license_key);
            },
            success: (response) => {
                console.log('Checkout closed after successful purchase:', response);
            },
        });
    }

    const buyBtn = document.getElementById("freemius-buy-btn");
    if (buyBtn) {
        buyBtn.addEventListener("click", () => openFreemiusCheckout(false));
    }

    const trialBtn = document.getElementById("freemius-trial-btn");
    if (trialBtn) {
        trialBtn.addEventListener("click", () => openFreemiusCheckout(true));
    }

    // Show freemius-activate form on button click
    const activateBtn = document.getElementById("freemius-activate-btn");
    const activateFormDiv = document.querySelector(".freemius-activate");
    if (activateBtn && activateFormDiv) {
        activateBtn.addEventListener("click", () => {
            activateFormDiv.style.display = "block";
        });
    }

    // License Key Activation Hook
    const licenseForm = document.getElementById('license-form');
    const refreshBtn = document.getElementById('freemius-validate-btn');

    function handleLicenseValidation(e, licenseKey = null) {
        if (e) e.preventDefault();
        const key = licenseKey || document.getElementById('gptpro_license_key')?.value || document.getElementById('gptpro_license_key_data')?.dataset.gptproLicenseKey;
        const msg = document.getElementById('license-message');
        console.log('License element clicked - checking license vars');
        if (!key || !msg) {
            console.log('Missing key or msg element');
            return;
        }
        msg.textContent = '';
        fetch(buildAppUrl(`/mailbox/${mailboxId}/freescoutgptpro/validate-license`), {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.getAttribute('content')
            },
            body: JSON.stringify({ gptpro_license_key: key })
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                msg.style.color = 'green';
                msg.textContent = 'Result: License validated successfully. Reloading...';
                setTimeout(() => location.reload(), 2500);
            } else {
                msg.style.color = 'red';
                msg.textContent = 'Result: ' + data.error || 'Result: Issue with license validation, please check your license key.';
                // setTimeout(() => location.reload(), 5000);
            }
        })
        .catch(() => { msg.textContent = 'Error validating license.'; });
    }

    if (licenseForm) {
        console.log('License form submit click event listener added');
        licenseForm.addEventListener('submit', handleLicenseValidation);
    }
    if (refreshBtn) {
        console.log('Refresh btn click event listener added');
        refreshBtn.addEventListener('click', handleLicenseValidation);
    }

    // Deactivate License Button Handler
    const deactivateBtn = document.getElementById('freemius-deactivate-btn');
    if (deactivateBtn) {
        deactivateBtn.addEventListener('click', function(e) {
            e.preventDefault();
            const msg = document.getElementById('license-message');
            if (!confirm('Are you sure you want to deactivate this license? This will remove the license from this installation.')) {
                return;
            }
            deactivateBtn.disabled = true;
            const origText = deactivateBtn.textContent;
            deactivateBtn.textContent = 'Deactivating...';
            if (msg) {
                msg.style.color = 'inherit';
                msg.textContent = 'Result: Deactivating license...';
            }
            
            fetch(buildAppUrl(`/mailbox/${mailboxId}/freescoutgptpro/deactivate-license`), {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.getAttribute('content')
                },
                body: JSON.stringify({})
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    if (msg) {
                        msg.style.color = 'green';
                        msg.textContent = 'Result: License deactivated successfully. Reloading...';
                    }
                    setTimeout(() => location.reload(), 1500);
                } else {
                    if (msg) {
                        msg.style.color = 'red';
                        msg.textContent = 'Result: ' + (data.error || 'Error deactivating license.');
                    }
                    deactivateBtn.disabled = false;
                    deactivateBtn.textContent = origText;
                }
            })
            .catch(err => {
                if (msg) {
                    msg.style.color = 'red';
                    msg.textContent = 'Result: Error deactivating license: ' + err;
                }
                deactivateBtn.disabled = false;
                deactivateBtn.textContent = origText;
            });
        });
    }

    const settingsForm = document.querySelector("form.form-horizontal");
    const modelSelect = document.getElementById("model");
    const apiKeyInput = document.querySelector("input[name='api_key']");
    const openAiApiKeyGroup = document.getElementById("openai-api-key-group");
    const gatewayEnabledInput = document.getElementById("llm_gateway_enabled");
    const gatewayBaseUrlInput = document.getElementById("llm_gateway_base_url");
    const gatewayApiKeyInput = document.getElementById("llm_gateway_api_key");
    const gatewayProviderSelect = document.getElementById("llm_gateway_provider");
    const gatewayProviderWarning = document.getElementById("gateway-provider-warning");
    const refreshProvidersBtn = document.getElementById("refresh-providers-btn");
    const gatewayEmbeddingModelInput = document.getElementById("llm_gateway_embedding_model");
    const gatewayEmbeddingModelGroup = document.getElementById("llm-gateway-embedding-model-group");
    const embeddingProviderUrlInput = document.getElementById("llm_embedding_provider_url");
    const embeddingProviderUrlGroup = document.getElementById("llm-embedding-provider-url-group");
    const embeddingApiKeyInput = document.getElementById("llm_embedding_api_key");
    const embeddingApiKeyGroup = document.getElementById("llm-embedding-api-key-group");
    const embeddingProviderSection = document.getElementById("llm-embedding-provider-section");
    const gatewaySettings = document.getElementById("llm-gateway-settings");
    const gatewayToggleLabel = document.querySelector('label[for="llm_gateway_enabled"]');
    const savedModel = modelSelect?.dataset?.savedModel || null;
    let cachedProviderRegistry = Array.isArray(providerRegistry) ? [...providerRegistry] : [];
    let previousGatewayProviderValue = gatewayProviderSelect?.value || 'custom';
    let previousProviderRegistrySnapshot = Array.isArray(cachedProviderRegistry) ? [...cachedProviderRegistry] : [];

    function setProviderWarning(message) {
        if (!gatewayProviderWarning) {
            return;
        }

        if (!message) {
            gatewayProviderWarning.style.display = 'none';
            gatewayProviderWarning.textContent = '';
            return;
        }

        gatewayProviderWarning.textContent = message;
        gatewayProviderWarning.style.display = 'block';
    }

    function getProviderWarningMessage(data) {
        if (data && data.warning) {
            return data.warning;
        }

        if (!Array.isArray(data?.providers) || data.providers.length === 0) {
            return providerSettings.providerRegistryFetchWarning;
        }

        return '';
    }

    function normalizeGatewayUrlForComparison(url) {
        if (!url) {
            return '';
        }

        return url.trim().replace(/\/+$/, '');
    }

    function setSelectedGatewayProvider() {
        if (!gatewayProviderSelect || !gatewayBaseUrlInput) {
            return;
        }

        const savedProviderValue = (gatewayProviderSelect.dataset.savedProvider || '').trim();

        if (savedProviderValue && cachedProviderRegistry.some((provider) => provider.id === savedProviderValue)) {
            gatewayProviderSelect.value = savedProviderValue;
            previousGatewayProviderValue = gatewayProviderSelect.value;
            return;
        }

        gatewayProviderSelect.value = 'custom';
        previousGatewayProviderValue = gatewayProviderSelect.value;
    }

    function hydrateProviderOptions() {
        if (!gatewayProviderSelect) {
            return;
        }

        gatewayProviderSelect.innerHTML = '<option value="custom">' + providerSettings.gatewayProviderCustomLabel + '</option>';
        if (!cachedProviderRegistry.length) {
            setSelectedGatewayProvider();
            return;
        }

        cachedProviderRegistry.forEach((provider) => {
            const option = document.createElement('option');
            option.value = provider.id;
            option.textContent = provider.name;
            gatewayProviderSelect.appendChild(option);
        });

        setSelectedGatewayProvider();
    }

    function loadProviders(forceRefresh = false) {
        if (!gatewayProviderSelect) {
            return;
        }

        // If not forcing refresh, use the pre-loaded provider registry
        if (!forceRefresh) {
            hydrateProviderOptions();
            
            if (providerRegistryWarning) {
                setProviderWarning(providerRegistryWarning);
            }
            return;
        }

        // Force refresh - save the current registry in case the fetch fails
        previousProviderRegistrySnapshot = Array.isArray(cachedProviderRegistry) ? [...cachedProviderRegistry] : [];

        // Force refresh - make a POST request to refresh from remote
        fetch(buildAppUrl('/freescoutgptpro/providers'), {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.getAttribute('content')
            },
            body: JSON.stringify({ refresh: true })
        })
        .then(response => response.json())
        .then(data => {
            const newProviders = Array.isArray(data?.providers) && data.providers.length ? data.providers : [];
            if (newProviders.length > 0) {
                cachedProviderRegistry = newProviders;
            } else if (previousProviderRegistrySnapshot.length > 0) {
                // If the fetch returned an empty list, restore the previous snapshot
                cachedProviderRegistry = [...previousProviderRegistrySnapshot];
            } else {
                // If the fetch returned an empty list and there's no snapshot, clear the registry
                cachedProviderRegistry = [];
            }
            hydrateProviderOptions();

            const warningMessage = data?.warning || '';
            setProviderWarning(warningMessage);
            if (refreshProvidersBtn) {
                refreshProvidersBtn.disabled = false;
                refreshProvidersBtn.textContent = providerSettings.refreshProvidersLabel;
            }
        })
        .catch(() => {
            // On network error, restore the previous snapshot
            if (previousProviderRegistrySnapshot.length > 0) {
                cachedProviderRegistry = [...previousProviderRegistrySnapshot];
            }
            hydrateProviderOptions();
            setProviderWarning(providerSettings.providerRegistryFetchWarning);
            if (refreshProvidersBtn) {
                refreshProvidersBtn.disabled = false;
                refreshProvidersBtn.textContent = providerSettings.refreshProvidersLabel;
            }
        });
    }

    function applyGatewayProviderSelection() {
        if (!gatewayProviderSelect || !gatewayBaseUrlInput) {
            return;
        }

        const selectedProviderId = gatewayProviderSelect.value;
        if (!selectedProviderId || selectedProviderId === 'custom') {
            if (previousGatewayProviderValue !== 'custom') {
                gatewayBaseUrlInput.value = '';
            }
            previousGatewayProviderValue = selectedProviderId || 'custom';
            return;
        }

        const selectedProvider = cachedProviderRegistry.find((provider) => provider.id === selectedProviderId);
        if (selectedProvider && selectedProvider.base_url) {
            gatewayBaseUrlInput.value = selectedProvider.base_url;
        }
        previousGatewayProviderValue = selectedProviderId;
    }

    function setModelSelectPlaceholder(message) {
        if (!modelSelect) {
            return;
        }

        const option = document.createElement("option");
        option.value = "";
        option.textContent = message;
        modelSelect.replaceChildren(option);
    }

    function resetModelOptions(message = "Enter an OpenAI API key to load models") {
        setModelSelectPlaceholder(message);
    }

    function fetchModels() {
        if (!modelSelect) {
            return;
        }

        const gatewayEnabled = !!gatewayEnabledInput?.checked;
        const apiKey = apiKeyInput?.value?.trim() || "";
        const gatewayBaseUrl = gatewayBaseUrlInput?.value?.trim() || "";
        const gatewayApiKey = gatewayApiKeyInput?.value?.trim() || "";

        if (gatewayEnabled && (!gatewayBaseUrl || !gatewayApiKey)) {
            resetModelOptions("Enter gateway URL and key to load models");
            return;
        }
        if (!gatewayEnabled && !apiKey) {
            resetModelOptions("Enter an OpenAI API key to load models");
            return;
        }

        console.log('fetchModels');
        fetch(buildAppUrl('/freescoutgptpro/get-models'), {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content,
            },
            body: JSON.stringify({
                api_key: apiKey,
                llm_gateway_enabled: gatewayEnabled,
                llm_gateway_base_url: gatewayBaseUrl,
                llm_gateway_api_key: gatewayApiKey,
            }),
        })
        .then(response => response.json())
        .then(data => {
            setModelSelectPlaceholder("Select an API model");
            if (data.data) {
                const models = Object.values(data.data);
                models.forEach(model => {
                    const option = document.createElement("option");
                    option.value = model.id;
                    option.textContent = model.id;

                    if (model.id === savedModel) {
                        option.selected = true;
                    }

                    modelSelect.appendChild(option);
                });
            } else {
                console.log('No models found or invalid data format');
            }
        })
        .catch(error => console.error("Error fetching models:", error));
    }

    function updateGatewayState() {
        const gatewayEnabled = !!gatewayEnabledInput?.checked;

        if (gatewaySettings) {
            gatewaySettings.style.display = gatewayEnabled ? "block" : "none";
        }
        if (gatewayEmbeddingModelGroup) {
            gatewayEmbeddingModelGroup.style.display = gatewayEnabled ? "block" : "none";
        }
        if (embeddingProviderSection) {
            embeddingProviderSection.style.display = gatewayEnabled ? "block" : "none";
        }
        if (embeddingProviderUrlGroup) {
            embeddingProviderUrlGroup.style.display = gatewayEnabled ? "block" : "none";
        }
        if (embeddingApiKeyGroup) {
            embeddingApiKeyGroup.style.display = gatewayEnabled ? "block" : "none";
        }
        if (openAiApiKeyGroup) {
            openAiApiKeyGroup.style.display = gatewayEnabled ? "none" : "block";
        }
        if (gatewayBaseUrlInput) {
            gatewayBaseUrlInput.required = gatewayEnabled;
            gatewayBaseUrlInput.disabled = !gatewayEnabled;
        }
        if (gatewayApiKeyInput) {
            gatewayApiKeyInput.required = gatewayEnabled;
            gatewayApiKeyInput.disabled = !gatewayEnabled;
        }
        if (gatewayEmbeddingModelInput) {
            gatewayEmbeddingModelInput.disabled = !gatewayEnabled;
        }
        if (apiKeyInput) {
            apiKeyInput.required = !gatewayEnabled;
            apiKeyInput.disabled = gatewayEnabled;
        }
    }

    function syncGatewayState(clearModels = false) {
        updateGatewayState();

        if (!modelSelect) {
            return;
        }

        if (clearModels) {
            modelSelect.value = "";
        }

        const gatewayEnabled = !!gatewayEnabledInput?.checked;
        if (gatewayEnabled) {
            fetchModels();
        } else {
            const apiKey = apiKeyInput?.value?.trim() || "";
            if (apiKey) {
                fetchModels();
            } else {
                resetModelOptions("Enter an OpenAI API key to load models");
            }
        }
    }

    if (gatewayEnabledInput) {
        syncGatewayState(false);
        gatewayEnabledInput.addEventListener("change", function () {
            syncGatewayState(true);
        });
        gatewayEnabledInput.addEventListener("click", function () {
            window.requestAnimationFrame(function () {
                syncGatewayState(true);
            });
        });
        gatewayToggleLabel?.addEventListener("click", function () {
            window.requestAnimationFrame(function () {
                syncGatewayState(true);
            });
        });
    }

    if (gatewayProviderSelect) {
        gatewayProviderSelect.addEventListener('change', function () {
            applyGatewayProviderSelection();
            const gatewayEnabled = !!gatewayEnabledInput?.checked;
            if (gatewayEnabled && gatewayApiKeyInput?.value) {
                fetchModels();
            }
        });
    }

    if (refreshProvidersBtn) {
        refreshProvidersBtn.addEventListener('click', function () {
            refreshProvidersBtn.disabled = true;
            refreshProvidersBtn.textContent = providerSettings.refreshingProvidersLabel;
            loadProviders(true);
        });
    }

    loadProviders(false);

    settingsForm?.addEventListener("submit", function () {
        syncGatewayState(false);
    });

    if (modelSelect) {
        if ((gatewayEnabledInput?.checked && gatewayBaseUrlInput?.value && gatewayApiKeyInput?.value) || (!gatewayEnabledInput?.checked && apiKeyInput?.value)) {
            fetchModels();
        } else if (!gatewayEnabledInput?.checked) {
            resetModelOptions("Enter an OpenAI API key to load models");
        } else {
            resetModelOptions("Enter gateway URL and key to load models");
        }

        apiKeyInput?.addEventListener("blur", function () {
            fetchModels();
        });

        gatewayBaseUrlInput?.addEventListener("blur", function () {
            fetchModels();
        });

        gatewayApiKeyInput?.addEventListener("blur", function () {
            fetchModels();
        });
        // --- Clear Cache Button Handler ---
        $(document).on('click', '.clear-cache-btn', function(e) {
            e.preventDefault();
            var btn = $(this);
            var cacheType = btn.data('cache-type');
            btn.prop('disabled', true);
            var origText = btn.text();
            btn.text('Clearing...');
            fetch(buildAppUrl('/freescoutgptpro/clear-cache') + '?mailbox=' + mailboxId, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                },
                body: JSON.stringify({ cache_type: cacheType })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    window.location.reload();
                } else {
                    alert('Failed clearing cache: ' + (data.error || 'Unknown error'));
                }
            })
            .catch(err => {
                alert('Error clearing cache: ' + err);
            })
            .finally(() => {
                btn.prop('disabled', false);
                btn.text(origText);
            });
        });
// --- Regenerate Vector Embeds and Content Cache Button Handler ---
$(document).on('click', '#regenerate-embeds-btn', function(e) {
    e.preventDefault();
    var btn = $(this);
    var status = $('#regenerate-embeds-status');
    btn.prop('disabled', true);
    status.text('Regenerating...').show();
    fetch(buildAppUrl('/freescoutgptpro/generate'), {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
        },
        body: new URLSearchParams({ mailbox_id: mailboxId, regenerate_only: 1 })
    })
    .then(response => {
        if (response.ok) {
            // Show flash message by reloading (server sets Session::flash)
            window.location.reload();
        } else {
            status.text('Error: ' + response.statusText).show();
            btn.prop('disabled', false);
        }
    })
    .catch(err => {
        status.text('Error: ' + err).show();
        btn.prop('disabled', false);
    });
});
    }
// FreeScout Widget Embed
    window.FreeScoutW = {
        s: {
            color: "#295a85",
            position: "br",
            locale: "en",
            show_categories: "1",
            id: 3539379351,
            category_id: 41
        }
    };

    if (!document.getElementById("freescout-w")) {
        const a = document.createElement("script");
        a.id = "freescout-w";
        a.src = "https://support.presswizards.com/modules/knowledgebase/js/widget.js?v=3666";
        a.async = true;
        document.getElementsByTagName("script")[0].parentNode.insertBefore(a, null);
    }
});
