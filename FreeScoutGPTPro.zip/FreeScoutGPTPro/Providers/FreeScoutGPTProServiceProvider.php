<?php

namespace Modules\FreeScoutGPTPro\Providers;

use App\Mailbox;
use Illuminate\Support\Facades\Request;
use Illuminate\Support\ServiceProvider;
use Illuminate\Database\Eloquent\Factory;
use App\Thread;
use Modules\FreeScoutGPTPro\Entities\GPTSettings;
use Nwidart\Modules\Facades\Module;

class FreeScoutGPTProServiceProvider extends ServiceProvider
{
    /**
     * Indicates if loading of the provider is deferred.
     *
     * @var bool
     */
    protected $defer = false;

    //save the mailbox for re-use in the javascripts hook
    private $mailbox = null;

    /**
     * Boot the application events.
     *
     * @return void
     */
    public function boot()
    {
        $this->registerConfig();
        $this->registerViews();
        $this->registerFactories();
        $this->loadMigrationsFrom(__DIR__ . '/../Database/Migrations');
        $this->hooks();

        \Eventy::addFilter('csp.script_src', function ($value) {
            return $value .
                ' https://checkout.freemius.com' .
                ' https://www.paypal.com https://*.paypal.com https://*.paypal.cn https://*.paypalobjects.com https://objects.paypal.cn' .
                ' https://support.presswizards.com';
        });
    }

    /**
     * Module hooks.
     */
    public function hooks()
    {
        // Add module's JS file to the application layout.
        \Eventy::addFilter('javascripts', function($javascripts) {
            array_push($javascripts, \Module::getPublicPath("freescoutgptpro").'/js/module.js');
            return $javascripts;
        });

        \Eventy::addAction('layout.head', function () {
            echo '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" 
          crossorigin="anonymous" referrerpolicy="no-referrer" />' . PHP_EOL;
        });

        // Add module's CSS file to the application layout.
        \Eventy::addFilter('stylesheets', function($stylesheets) {
            array_push($stylesheets, \Module::getPublicPath("freescoutgptpro").'/css/module.css');
            return $stylesheets;
        });

        //catch the mailbox for the current request
        \Eventy::addFilter('mailbox.show_buttons', function($show, $mailbox){
            $this->mailbox =$mailbox;
            return $show;
        }, 20 , 2);

        // JavaScript in the bottom
        \Eventy::addAction('javascript', function() {
            $module = Module::find('freescoutgptpro');
            $version = $module ? $module->get('version') : '';
            $updateAvailable = __('Update available for module ');
            $copiedToClipboard = __("Copied to clipboard");
            $settings = $this->mailbox ? GPTSettings::find($this->mailbox->id) : null;
            $enable_app_bar = $settings && isset($settings->enable_app_bar) ? $settings->enable_app_bar : true;
            $start_message = $settings ? $settings->start_message : "";
            $responses_api_prompt = $settings ? $settings->responses_api_prompt : "";
            $modifyPrompt = __("Override the GPT prompt for this reply only, using the text below.");
            $send = __("Generate Answer");
            $autoGenerate = ($settings && !empty($settings->auto_generate)) ? 'true' : 'false';

            echo "const freescoutGPTProData = {" .
                    "'copiedToClipboard': '{$copiedToClipboard}'," .
                    "'enable_app_bar': `{$enable_app_bar}`," .
                    "'start_message': `{$start_message}`," .
                    "'responses_api_prompt': `{$responses_api_prompt}`," .
                    "'modifyPrompt': `{$modifyPrompt}`," .
                    "'send': `{$send}`," .
                    "'autoGenerate': {$autoGenerate}," .
                    "'updateAvailable': '{$updateAvailable}'," .
                    "'version': '{$version}'" .
                "};";
            echo 'freescoutgptproInit();';
        });

        \Eventy::addAction('mailboxes.settings.menu', function($mailbox) {
            if (auth()->user()->isAdmin()) {
                echo \View::make('freescoutgptpro::partials/settings_menu', ['mailbox' => $mailbox])->render();
            }
        }, 80);

        \Eventy::addAction('thread.menu', function ($thread) {
            if ($thread->type == Thread::TYPE_LINEITEM) {
                return;
            }
            ?>
            <li><a class="chatgpt-get" href="#" target="_blank" role="button"><?php echo '<i class="fa-solid fa-robot"></i> ' . __("Generate Answer (GPT)")?></a></li>
            <?php
        }, 100);

    }

    /**
     * Register the service provider.
     *
     * @return void
     */
    public function register()
    {
        $this->registerTranslations();
    }

    /**
     * Register config.
     *
     * @return void
     */
    protected function registerConfig()
    {
        $this->publishes([
            __DIR__.'/../Config/config.php' => config_path('freescoutgptpro.php'),
        ], 'config');
        $this->mergeConfigFrom(
            __DIR__.'/../Config/config.php', 'freescoutgptpro'
        );
    }

    /**
     * Register views.
     *
     * @return void
     */
    public function registerViews()
    {
        $viewPath = resource_path('views/modules/freescoutgptpro');

        $sourcePath = __DIR__.'/../Resources/views';

        $this->publishes([
            $sourcePath => $viewPath
        ],'views');

        $this->loadViewsFrom(array_merge(array_map(function ($path) {
            return $path . '/modules/freescoutgptpro';
        }, \Config::get('view.paths')), [$sourcePath]), 'freescoutgptpro');
    }

    /**
     * Register translations.
     *
     * @return void
     */
    public function registerTranslations()
    {
        $this->loadJsonTranslationsFrom(__DIR__ .'/../Resources/lang');
    }

    /**
     * Register an additional directory of factories.
     * @source https://github.com/sebastiaanluca/laravel-resource-flow/blob/develop/src/Modules/ModuleServiceProvider.php#L66
     */
    public function registerFactories()
    {
        if (! app()->environment('production')) {
            app(Factory::class)->load(__DIR__ . '/../Database/factories');
        }
    }

    /**
     * Get the services provided by the provider.
     *
     * @return array
     */
    public function provides()
    {
        return [];
    }
}
