<?php

namespace Illuminate\Routing {
    class Controller {}
}

namespace Modules\FreeScoutGPTPro\Http\Controllers {
    class DummyController extends \Illuminate\Routing\Controller {}
}

namespace {
    require __DIR__ . '/../Http/Controllers/FreeScoutGPTProController.php';

    $controllerClass = 'Modules\\FreeScoutGPTPro\\Http\\Controllers\\FreeScoutGPTProController';
    $reflection = new \ReflectionClass($controllerClass);
    $method = $reflection->getMethod('buildUserFacingErrorMessage');
    $method->setAccessible(true);
    $instance = $reflection->newInstanceWithoutConstructor();

    $detail = $method->invoke($instance, 404, 'Not Found');
    echo $detail . PHP_EOL;

    if ($detail === 'Not Found' || stripos($detail, '404') === false) {
        exit(1);
    }
}
