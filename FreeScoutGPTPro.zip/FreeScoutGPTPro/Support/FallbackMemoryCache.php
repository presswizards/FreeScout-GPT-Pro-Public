<?php

namespace Modules\FreeScoutGPTPro\Support;

/**
 * A simple array-based cache wrapper that behaves like a Cache store.
 * Used as a fallback when file-based caching is not available.
 */
class FallbackMemoryCache
{
    private $store = [];
    private $expires = [];

    public function get($key, $default = null)
    {
        if (isset($this->expires[$key]) && time() > $this->expires[$key]) {
            unset($this->store[$key], $this->expires[$key]);
            return $default;
        }
        return $this->store[$key] ?? $default;
    }

    public function has($key)
    {
        // Check key existence, not value truthiness
        if (!isset($this->store[$key])) {
            return false;
        }
        // Check if expired
        if (isset($this->expires[$key]) && time() > $this->expires[$key]) {
            unset($this->store[$key], $this->expires[$key]);
            return false;
        }
        return true;
    }

    public function put($key, $value, $ttl = null)
    {
        $this->store[$key] = $value;
        if ($ttl !== null) {
            $expireTime = $this->calculateExpireTime($ttl);
            if ($expireTime !== null) {
                $this->expires[$key] = $expireTime;
            } else {
                // Clear any existing expiry if the new TTL is invalid
                unset($this->expires[$key]);
            }
        } else {
            // Clear any existing expiry if no TTL is provided
            unset($this->expires[$key]);
        }
        return true;
    }

    public function forget($key)
    {
        unset($this->store[$key], $this->expires[$key]);
        return true;
    }

    public function flush()
    {
        $this->store = [];
        $this->expires = [];
        return true;
    }

    private function calculateExpireTime($ttl)
    {
        if ($ttl === null) {
            return null;
        }

        // Handle datetime objects (Carbon, DateTime, etc.)
        if (is_object($ttl)) {
            // Check for DateInterval first to ensure it's handled before method checks
            if ($ttl instanceof \DateInterval) {
                try {
                    $now = new \DateTime();
                    $now->add($ttl);
                    return $now->getTimestamp();
                } catch (\Exception $e) {
                    return null;
                }
            }
            // For Carbon and DateTime objects, use their native method
            if (method_exists($ttl, 'getTimestamp')) {
                return $ttl->getTimestamp();
            }
            // For other unsupported objects, return null
            return null;
        }

        // Handle numeric values (TTL in seconds, per Laravel 5.8+)
        // Note: All current cache calls in this module use Carbon datetime objects,
        // so this handles edge cases only. Numeric values are treated as seconds.
        if (is_int($ttl) || is_float($ttl)) {
            if ($ttl > 0) {
                return time() + (int)$ttl;
            }
            return null;
        }

        return null;
    }
}
