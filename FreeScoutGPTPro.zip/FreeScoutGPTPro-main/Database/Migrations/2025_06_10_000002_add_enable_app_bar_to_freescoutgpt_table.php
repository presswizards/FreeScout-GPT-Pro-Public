<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddEnableAppBarToFreescoutgptTable extends Migration
{
    public function up()
    {
        Schema::table('freescoutgpt', function (Blueprint $table) {
            if (!Schema::hasColumn('freescoutgpt', 'enable_app_bar')) {
                $table->boolean('enable_app_bar')->default(false)->after('auto_generate');
            }
        });
    }

    public function down()
    {
        Schema::table('freescoutgpt', function (Blueprint $table) {
            if (Schema::hasColumn('freescoutgpt', 'enable_app_bar')) {
                $table->dropColumn('enable_app_bar');
            }
        });
    }
}
