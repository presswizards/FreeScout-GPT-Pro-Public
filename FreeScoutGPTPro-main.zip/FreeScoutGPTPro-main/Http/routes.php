<?php

Route::group(['middleware' => 'web', 'prefix' => \Helper::getSubdirectory(), 'namespace' => 'Modules\FreeScoutGPTPro\Http\Controllers'], function()
{
    Route::post('/freescoutgptpro/generate', 'FreeScoutGPTProController@generate');
    Route::get('/freescoutgptpro/answers', 'FreeScoutGPTProController@answers');
    Route::get('/freescoutgptpro/is_enabled', 'FreeScoutGPTProController@checkIsEnabled');
    Route::get('/mailbox/{mailbox_id}/freescoutgptpro-settings', ['uses' => 'FreeScoutGPTProController@settings', 'middleware' => ['auth', 'roles'], 'roles' => ['admin']])->name('freescoutgptpro.settings');
    Route::post('/mailbox/{mailbox_id}/freescoutgptpro-settings', ['uses' => 'FreeScoutGPTProController@saveSettings', 'middleware' => ['auth', 'roles'], 'roles' => ['admin']]);
    Route::post('/freescoutgptpro/get-models', 'FreeScoutGPTProController@getAvailableModels');
    Route::post('/mailbox/{mailbox_id}/freescoutgptpro/validate-license', [
        'uses' => 'FreeScoutGPTProController@validateLicenseKey',
        'middleware' => ['auth', 'roles'],
        'roles' => ['admin']
    ]);

    // Clear cache route
    Route::post('/freescoutgptpro/clear-cache', [
        'as' => 'freescoutgptpro.clear_cache',
        'uses' => 'FreeScoutGPTProController@clearCache',
        'middleware' => ['auth']
    ]);
});
