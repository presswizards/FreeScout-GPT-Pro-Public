<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddLicenseKeyToFreescoutgptTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('freescoutgpt', function (Blueprint $table) {
            if (!Schema::hasColumn('freescoutgpt', 'license_key')) {
                $table->string('license_key')->nullable()->after('mailbox_id');
            }
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('freescoutgpt', function (Blueprint $table) {
            if (Schema::hasColumn('freescoutgpt', 'license_key')) {
                $table->dropColumn('license_key');
            }
        });
    }
}
