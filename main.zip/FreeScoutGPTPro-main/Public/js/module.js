function freescoutgptproInit() {
    $(document).ready(function(){
        // Add event listeners
        $(document).on("click", ".chatgpt-get", generateAnswer);
        $(document).on("click", ".gptbutton", showModifyPromptAlert);
        $(document).on("click", ".gpt-nav-previous", previousAnswer);
        $(document).on("click", ".gpt-nav-next", nextAnswer);
        $(document).on("click", ".gpt-copy-icon", copyAnswer);
        $(document).on("click", ".gpt-close-modal", hideModifyPromptAlert);
        $(document).on("click", ".gpt-apply-modal", injectGptAnswer);
        $(document).on("click", ".gpt-reply-icon", replyWithGptAnswer);

        addModifyPromptAlert();
        // Run on both conversation and new-ticket pages
        if (
            document.location.pathname.startsWith("/conversation") ||
            document.location.pathname.match(/^\/mailbox\/\d+\/new-ticket$/)
        ) {
            const mailbox_id = $("body").attr("data-mailbox_id");
            $.ajax({
                url: '/freescoutgptpro/is_enabled?mailbox=' + mailbox_id,
                dataType: 'json',
                success: function (response, status) {
                    if (!response.enabled) {
                        $(".chatgpt-get").remove();
                        // Do not add robot or AI Edit buttons if not enabled
                        return;
                    }

                    // Add button to reply form (only if enabled)
                    $(".conv-block .note-toolbar > .note-btn-group:first").append(`
                        <button type="button" class="note-btn btn btn-default btn-sm gptbutton" tabindex="-1" title="ChatGPT Prompt Edit" aria-label="ChatGPT Prompt Edit" data-original-title="ChatGPT Prompt Edit">
                            <i class="fa-solid fa-robot"></i>
                        </button>
                        <div class="btn-group ai-edit-dropdown" style="display:inline-block;vertical-align:middle;">
                            <button type="button" class="note-btn btn btn-default btn-sm dropdown-toggle ai-edit-btn" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" title= data-original-title="AI Edit">
                                <i class="fa-solid fa-wand-magic-sparkles"></i> AI Edit <span class="caret"></span>
                            </button>
                            <ul class="dropdown-menu ai-edit-menu">
                                <li><a href="#" data-ai-action="fix_spelling">Fix spelling and grammar</a></li>
                                <li><a href="#" data-ai-action="longer">Make it longer</a></li>
                                <li><a href="#" data-ai-action="shorter">Make it shorter</a></li>
                                <li><a href="#" data-ai-action="friendlier">Make it friendlier</a></li>
                                <li><a href="#" data-ai-action="professional">Make it more professional</a></li>
                            </ul>
                        </div>
                    `);
                    // Initialize Bootstrap tooltips for dynamically added buttons
                    setTimeout(function() {
                        $('.note-btn[data-original-title], .ai-edit-btn[data-original-title]').tooltip({container: 'body', placement: 'bottom'});
                    }, 0);

                    // AI Edit dropdown event
                    $(document).on("click", ".ai-edit-menu a", function(e) {
                        e.preventDefault();
                        const action = $(this).data("ai-action");
                        aiEditSelectedText(action);
                    });

                    // Modal Replace/Cancel events
                    $(document).on("click", "#ai-edit-modal-cancel", function() {
                        $("#ai-edit-modal").modal("hide");
                    });
                    $(document).on("click", "#ai-edit-modal-replace", function() {
                        const newText = $("#ai-edit-modal-text").val();
                        replaceSelectedOrAllInReply(newText);
                        $("#ai-edit-modal").modal("hide");
                    });

                    addModifyPromptAlert();
                }
            });

            const conversation_id = $("body").attr("data-conversation_id");
            $.ajax({
                url: '/freescoutgptpro/answers?conversation=' + conversation_id,
                dataType: 'json',
                success: function (response, status) {
                    response.answers.forEach(function (item, index, array) {
                        item.answers.forEach(function (i, ind, arr) {
                            addAnswer(item.thread, i);
                        });
                        $(`#thread-${item.thread} .gpt-answer`).last().removeClass("hidden");
                        $(`#thread-${item.thread} .gpt-current-answer`).text($(`#thread-${item.thread} .gpt-answers div`).length);
                    });

                    // Auto-generate answer if enabled and not already triggered for this conversation
                    if (typeof freescoutGPTProData !== 'undefined' && freescoutGPTProData.autoGenerate) {
                        // Find the first customer thread without any GPT answer or loading placeholder, and not already triggered
                        const customerThreads = $(".thread-type-customer");
                        customerThreads.each(function() {
                            const thread = $(this);
                            // Skip if already triggered (e.g., on reload while generating)
                            if (thread.attr('data-gpt-autogen-triggered') === '1') return;
                            // No GPT answer and no loading placeholder
                            const hasGptAnswer = thread.find('.gpt-answer').length > 0;
                            const hasLoading = thread.find('.gpt-answer').filter(function(){ return $(this).text().trim() === 'Generating answer...'; }).length > 0;
                            if (!hasGptAnswer && !hasLoading) {
                                const chatgptBtn = thread.find('.chatgpt-get');
                                if (chatgptBtn.length) {
                                    thread.attr('data-gpt-autogen-triggered', '1');
                                    generateAnswer({ preventDefault: function(){}, target: chatgptBtn[0] });
                                }
                                // Only trigger for the first eligible thread
                                return false;
                            }
                        });
                    }
                }
            });
        }
    });
}

function generateAnswer(e) {
    e.preventDefault();
    const text = $(e.target).closest(".thread").children(".thread-message").children(".thread-body").children(".thread-content").get(0).innerHTML.replace(/<\/?[.*?]>/g, "").trim();
    const query = encodeURIComponent(text);
    const thread_id = $(e.target).closest(".thread").attr("data-thread_id");
    const mailbox_id = $("body").attr("data-mailbox_id");

    const customer_name = encodeURIComponent($(".customer-name").text());
    const customer_email = encodeURIComponent($(".customer-email").text().trim());
    const conversation_subject = encodeURIComponent($(".conv-subjtext span").text().trim());

    // Show loader and yellow GPT box with pulsing robot
    $(`#thread-${thread_id} .thread-info`).prepend("<img class=\"gpt-loader\" src=\"/modules/freescoutgptpro/img/loading.gif\" alt=\"GPT Loading Icon\">");
    addAnswer(thread_id, "");
    const gptBox = $(`#thread-${thread_id} .gpt`).first();
    gptBox.addClass('gpt-loading');
    gptBox.find('i.fa-robot').addClass('fa-beat-fade');

    fsAjax(`mailbox_id=${mailbox_id}&query=${query}&thread_id=${thread_id}&customer_name=${customer_name}&customer_email=${customer_email}&conversation_subject=${conversation_subject}`, '/freescoutgptpro/generate', function (response) {
        // Update the last gpt-answer with the real answer
        const answerDiv = $(`#thread-${thread_id} .gpt-answer`).last();
        answerDiv.html(response.answer);
        answerDiv.removeClass("hidden");
        gptBox.removeClass('gpt-loading');
        gptBox.find('i.fa-robot').removeClass('fa-beat-fade');
        $(`#thread-${thread_id} .gpt-current-answer`).text($(`#thread-${thread_id} .gpt-answers div`).length);
        $(`#thread-${thread_id} .gpt-loader`).remove();
    }, true, function() {
        showFloatingAlert('error', Lang.get("messages.ajax_error"));
        $(`#thread-${thread_id} .gpt-loader`).remove();
        gptBox.removeClass('gpt-loading');
        gptBox.find('i.fa-robot').removeClass('fa-beat-fade');
    });
}

function addAnswer(thread_id, text) {
    const gptSelector = `#thread-${thread_id} .gpt`;
    const answersSelector = `#thread-${thread_id} .gpt-answers`;
    // If no GPT box, add it
    if (!$(gptSelector).length) {
        $(`#thread-${thread_id}`).prepend(`<div class="gpt">
            <strong><i style="font-size:20px;" class="fa-solid fa-robot"></i> From FreeScout GPT Pro:</strong>
            <br />
            <div class="gpt-answers-data">
                <div class="gpt-nav">
                    <svg style="margin-right: 2px" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-left gpt-nav-previous" viewBox="0 0 16 16">
                        <path fill-rule="evenodd" d="M15 8a.5.5 0 0 0-.5-.5H2.707l3.147-3.146a.5.5 0 1 0-.708-.708l-4 4a.5.5 0 0 0 0 .708l4 4a.5.5 0 0 0 .708-.708L2.707 8.5H14.5A.5.5 0 0 0 15 8z"/>
                    </svg>
                    <span class="gpt-current-answer">1</span>/<span class="gpt-max-answer">1</span>
                    <svg style="margin-left: 2px" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-right gpt-nav-next" viewBox="0 0 16 16">
                        <path fill-rule="evenodd" d="M1 8a.5.5 0 0 1 .5-.5h11.793l-3.147-3.146a.5.5 0 0 1 .708-.708l4 4a.5.5 0 0 1 0 .708l-4 4a.5.5 0 0 1-.708-.708L13.293 8.5H1.5A.5.5 0 0 1 1 8z"/>
                    </svg>
                </div>
                <div class="gpt-answers"></div>
                <span class="gpt-copy-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-clipboard" viewBox="0 0 16 16">
                        <path d="M4 1.5H3a2 2 0 0 0-2 2V14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V3.5a2 2 0 0 0-2-2h-1v1h1a1 1 0 0 1 1 1V14a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V3.5a1 1 0 0 1 1-1h1v-1z"/>
                        <path d="M9.5 1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5v-1a.5.5 0 0 1 .5-.5h3zm-3-1A1.5 1.5 0 0 0 5 1.5v1A1.5 1.5 0 0 0 6.5 4h3A1.5 1.5 0 0 0 11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3z"/>
                    </svg>
                </span>
                <span class="gpt-reply-icon" title="Reply with this answer" style="cursor:pointer;margin-left:15px;display: inline-flex;align-items:center;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" stroke="currentColor" 
                        stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 16 16">
                        <path d="M12 14 V4 A2 2 0 0 0 10 2 H4 M5 1 L3 2 L5 3" />
                    </svg>
                </span>
            </div>
        </div>`);
    }
    if (text === "") {
        // Show loading placeholder as the last answer, hide all others
        $(answersSelector + ' .gpt-answer').addClass('hidden');
        $(answersSelector).append(`
            <div class="gpt-answer"><span class="gpt-generating-text fa-beat-fade">Generating answer...</span></div>
        `);
    } else {
        // Remove any loading placeholders, keep real answers
        $(answersSelector + ' .gpt-answer').each(function() {
            if ($(this).text().trim() === 'Generating answer...') {
                $(this).remove();
            }
        });
        // Hide all previous answers
        $(answersSelector + ' .gpt-answer').addClass('hidden');
        // Add the new answer and show it
        $(answersSelector).append(`
            <div class="gpt-answer">${text}</div>
        `);
    }
    // Update answer counters
    const total = $(`#thread-${thread_id} .gpt-answers div`).length;
    $(`#thread-${thread_id} .gpt-max-answer`).text(total);
    $(`#thread-${thread_id} .gpt-current-answer`).text(total);
    const robotIcon = document.querySelector('.gpt > strong > i.fa-solid.fa-robot');
    if (text !== "") {
        robotIcon.classList.add('fa-fade');
        setTimeout(() => {
          robotIcon.classList.remove('fa-fade');
        }, 800);
    }
}

function previousAnswer(e) {
    const thread_id = $(e.target).closest(".thread").attr("data-thread_id");
    const current_answer = $(`#thread-${thread_id} .gpt-answer`).not(".hidden");
    const previous_answer = current_answer.prev();
    const current_answer_number = $(`#thread-${thread_id} .gpt-current-answer`);

    if (!previous_answer.length) return

    current_answer.addClass("hidden");
    previous_answer.removeClass("hidden");
    current_answer_number[0].innerHTML -= 1;
}

function nextAnswer(e) {
    const thread_id = $(e.target).closest(".thread").attr("data-thread_id");
    const current_answer = $(`#thread-${thread_id} .gpt-answer`).not(".hidden");
    const next_answer = current_answer.next();
    const current_answer_number = $(`#thread-${thread_id} .gpt-current-answer`);

    if (!next_answer.length) return

    current_answer.addClass("hidden");
    next_answer.removeClass("hidden");
    current_answer_number[0].innerHTML = current_answer_number[0].innerHTML - 0 + 1;
}

function copyAnswer(e) {
    const thread_id = $(e.target).closest(".thread").attr("data-thread_id");
    const current_answer = $(`#thread-${thread_id} .gpt-answer`).not(".hidden");
    navigator.clipboard.writeText(current_answer[0].innerHTML.replace(/<\/?.*?>/g, "").replaceAll("```", ""));
    showFloatingAlert('success', freescoutGPTProData.copiedToClipboard);
}

async function injectGptAnswer(){
    let text, thread_id;
    const thread = $(".thread-type-customer:first");
    if (thread.length) {
        // Normal conversation view
        text = thread.children(".thread-message").children(".thread-body").children(".thread-content").get(0).innerHTML.replace(/<\/?[.*?]>/g, "").trim();
        thread_id = thread.attr("data-thread_id");
    } else {
        // New conversation modal/editor
        text = "New conversation";
        thread_id = null;
    }
    const query = encodeURIComponent(text);
    const mailbox_id = $("body").attr("data-mailbox_id");
    const customer_name = encodeURIComponent($(".customer-name").text());
    const customer_email = encodeURIComponent($(".customer-email").text().trim());
    const conversation_subject = encodeURIComponent($(".conv-subjtext span").text().trim());
    const command = $("#gpt-modified-prompt").val();

    $(".gptbutton").addClass("fa-beat-fade");
    hideModifyPromptAlert();

    fsAjax(`mailbox_id=${mailbox_id}&query=${query}&command=${encodeURIComponent(command)}&thread_id=${thread_id || ''}&customer_name=${customer_name}&customer_email=${customer_email}&conversation_subject=${conversation_subject}`, '/freescoutgptpro/generate', function (response) {
        $('#body').summernote('pasteHTML', response.answer.replace(/\n/g, "<br>"));
        $(".gptbutton").removeClass("fa-beat-fade");
    }, true, function() {
        $(".gptbutton").removeClass("fa-beat-fade");
        showFloatingAlert('error', Lang.get("messages.ajax_error"));
    });
}

function addModifyPromptAlert() {
    $('body').append(`
        <div class="modal fade" aria-hidden="false" tabindex="-1" style="display: none;" id="gpt-prompt-append">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close gpt-close-modal" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                        <h4 class="modal-title">${freescoutGPTProData.modifyPrompt}</h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-group" style="overflow:auto;">
                            <textarea rows="15" class="form-control note-form-control note-input col-md-12" id="gpt-modified-prompt"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" href="#" class="btn btn-primary note-btn note-btn-primary gpt-apply-modal">
                            ${freescoutGPTProData.send}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `);
    $("#gpt-modified-prompt").val(freescoutGPTProData.start_message);
}

function showModifyPromptAlert() {
    const alert = $("#gpt-prompt-append");
    alert[0].classList.add("in");
    alert.css("display", "block");
    $("body").append(`
        <div class="modal-backdrop fade in"></div>
    `);
}

function hideModifyPromptAlert() {
    const alert = $("#gpt-prompt-append");
    alert[0].classList.remove("in");
    alert.css("display", "none");
    $(".modal-backdrop").remove();
    $("#gpt-modified-prompt").val(freescoutGPTProData.start_message);
}

function replyWithGptAnswer(e) {
    // Find the thread and the visible GPT answer
    const thread = $(e.target).closest(".thread");
    const thread_id = thread.attr("data-thread_id");
    const gptAnswerDiv = $(`#thread-${thread_id} .gpt-answer`).not(".hidden");
    if (!gptAnswerDiv.length) return;
    // Get HTML content and preserve newlines as <br>
    let gptHtml = gptAnswerDiv[0].innerHTML;
    // If the answer is plain text (no block tags), convert newlines to <br>
    if (!/<\s*(p|ul|ol|li|div|table|pre|blockquote|h[1-6])\b/i.test(gptHtml)) {
        gptHtml = gptHtml.replace(/\n/g, '<br>');
    }
    // Trigger click on the normal reply button
    $(".conv-reply").first().trigger("click");
    // Paste the GPT answer HTML into the reply editor
    setTimeout(function() {
        $('#body').summernote('pasteHTML', gptHtml);
    }, 200); // Delay to ensure editor is open
}

// --- AI Edit Modal and Logic ---

function aiEditSelectedText(action) {
    // Get selected text in Summernote editor, or all if none
    let selectedText = getSelectedTextFromSummernote();
    let isPartial = !!selectedText && selectedText.length > 0;

    // --- FIX: Use Summernote's API to get selection if available ---
    if (!isPartial) {
        // If nothing selected, use the entire message (plain text)
        selectedText = $('#body').summernote('code').replace(/<\/?[^>]+(>|$)/g, "").trim();
        if (!selectedText) {
            showFloatingAlert('warning', 'No text found in the reply editor.');
            return;
        }
    }

    // Show loading modal
    showAiEditModal("Waiting for AI response...", true, isPartial);

    // Get mailbox_id from body attribute (like generate)
    const mailbox_id = $("body").attr("data-mailbox_id");

    // Send to backend for AI edit
    $.ajax({
        url: '/freescoutgptpro/ai_edit',
        method: 'POST',
        data: {
            text: selectedText,
            action: action,
            mailbox_id: mailbox_id
        },
        dataType: 'json',
        success: function(response) {
            showAiEditModal(response.edited || '', false, isPartial);
        },
        error: function() {
            showAiEditModal("Error communicating with AI service.", false, isPartial);
        }
    });
}

function showAiEditModal(text, loading, isPartial) {
    // Remove existing modal and any leftover overlays/backdrops
    $("#ai-edit-modal").remove();
    $(".modal-backdrop").remove();

    // Build modal HTML
    const modalHtml = `
        <div class="modal fade" id="ai-edit-modal" tabindex="-1" role="dialog" aria-labelledby="aiEditModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="aiEditModalLabel">AI Edit Result</h4>
                    </div>
                    <div class="modal-body">
                        <textarea id="ai-edit-modal-text" class="form-control" rows="10" style="resize:vertical;" ${loading ? "disabled" : ""}>${text}</textarea>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" id="ai-edit-modal-cancel" data-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary" id="ai-edit-modal-replace" data-partial="${isPartial ? "1" : "0"}" ${loading ? "disabled" : ""}>Replace</button>
                    </div>
                </div>
            </div>
        </div>
    `;
    $("body").append(modalHtml);

    // Bootstrap's .modal() triggers the modal and sets body.modal-open (which disables scroll)
    $('#ai-edit-modal').modal({
        backdrop: 'static',
        keyboard: false,
        show: true
    });

    // The following handlers clean up the modal and restore scroll
    $('#ai-edit-modal').on('hidden.bs.modal', function () {
        setTimeout(function() {
            $(".modal-backdrop").remove();
            $("#ai-edit-modal").remove();
            $('body').removeClass('modal-open').css('overflow', '');
        }, 300);
    });

    $('#ai-edit-modal-cancel, #ai-edit-modal-replace').off('click._backdropfix').on('click._backdropfix', function() {
        setTimeout(function() {
            $(".modal-backdrop").remove();
            $('body').removeClass('modal-open').css('overflow', '');
        }, 300);
    });
}

// Replace selected text or all in reply, depending on isPartial
function replaceSelectedOrAllInReply(newText) {
    $('#body').summernote('focus');
    let isPartial = $('#ai-edit-modal-replace').attr('data-partial') === "1";
    // Convert newlines to <br> for HTML insertion
    let htmlText = $('<div>').text(newText).html().replace(/\n/g, "<br>");
    if (isPartial) {
        // Use Summernote's native API to replace selection with HTML
        $('#body').summernote('pasteHTML', htmlText);
    } else {
        // Replace all
        $('#body').summernote('code', htmlText);
    }
}
function getSelectedTextFromSummernote() {
    // Try to use Summernote's native API for selection
    let editor = $('#body');
    if (editor.length && editor.summernote) {
        let range = editor.summernote('createRange');
        if (range && !range.isCollapsed()) {
            let selected = range.toString();
            if (selected && selected.replace(/\s/g, '').length > 0) {
                return selected;
            }
        }
    }
    // Fallback to window.getSelection for legacy support
    let selObj = window.getSelection();
    if (selObj && selObj.rangeCount > 0) {
        let range = selObj.getRangeAt(0);
        let container = $(range.commonAncestorContainer);
        if (
            container.closest('.note-editable').length > 0 &&
            container.closest('#body').length > 0
        ) {
            let selected = selObj.toString();
            if (selected && selected.replace(/\s/g, '').length > 0) {
                return selected;
            }
        }
    }
    return '';
}