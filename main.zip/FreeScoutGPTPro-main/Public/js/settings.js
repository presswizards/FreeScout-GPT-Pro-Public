document.addEventListener("DOMContentLoaded", function () {
    const mailboxId = document.getElementById('freescout-gpt-pro-container').dataset.mailboxId;
    const robotIcons = document.querySelectorAll('i.fa-solid.fa-robot');
    robotIcons.forEach(icon => {
        icon.classList.add('fa-fade');
        setTimeout(() => {
            icon.classList.remove('fa-fade');
        }, 3000);
    });

    const handler = new FS.Checkout({
        product_id: '19065',
        plan_id: '31580',
        public_key: 'pk_25feb8abb0fabc990c5ab3d30a94e',
    });

    const lastCheckKey = `gptpro_license_check_${mailboxId}`;
    const lastCheck = localStorage.getItem(lastCheckKey);
    const now = Date.now();
    if (!lastCheck || now - parseInt(lastCheck, 10) > 24 * 60 * 60 * 1000) {
        if (typeof handleLicenseValidation === 'function') {
            handleLicenseValidation();
            localStorage.setItem(lastCheckKey, now.toString());
        }
    }

    function openFreemiusCheckout(trial = false) {
        handler.open({
            licenses: 1,
            // billing_cycle: 'annual',
            billing_cycle_selector: 'responsive_list',
            show_reviews: true,
            trial, // trial: true or false
            purchaseCompleted: (response) => {
                console.log('Purchase completed:', response);
                handleLicenseValidation(null, response.license_key);
            },
            success: (response) => {
                console.log('Checkout closed after successful purchase:', response);
            },
        });
    }

    const buyBtn = document.getElementById("freemius-buy-btn");
    if (buyBtn) {
        buyBtn.addEventListener("click", () => openFreemiusCheckout(false));
    }

    const trialBtn = document.getElementById("freemius-trial-btn");
    if (trialBtn) {
        trialBtn.addEventListener("click", () => openFreemiusCheckout(true));
    }

    // License Key Activation Hook
    const licenseForm = document.getElementById('license-form');
    const refreshBtn = document.getElementById('freemius-validate-btn');

    function handleLicenseValidation(e, licenseKey = null) {
        if (e) e.preventDefault();
        const key = licenseKey || document.getElementById('gptpro_license_key')?.dataset.gptproLicenseKey || document.getElementById('gptpro_license_key')?.value;
        const msg = document.getElementById('license-message');
        console.log('License element clicked - checking license vars');
        if (!key || !msg) {
            console.log('Missing key or msg element');
            return;
        }
        msg.textContent = '';
        fetch(`/mailbox/${mailboxId}/freescoutgptpro/validate-license`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.getAttribute('content')
            },
            body: JSON.stringify({ gptpro_license_key: key })
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                msg.style.color = 'green';
                msg.textContent = 'License validated.';
                setTimeout(() => location.reload(), 1500);
            } else {
                msg.style.color = 'red';
                msg.textContent = data.error || 'Issue with license validation';
                setTimeout(() => location.reload(), 3500);
            }
        })
        .catch(() => { msg.textContent = 'Error validating license.'; });
    }

    if (licenseForm) {
        console.log('License form submit click event listener added');
        licenseForm.addEventListener('submit', handleLicenseValidation);
    }
    if (refreshBtn) {
        console.log('Refresh btn click event listener added');
        refreshBtn.addEventListener('click', handleLicenseValidation);
    }

    const modelSelect = document.getElementById("model");
    if (modelSelect) {
        const apiKeyInput = document.querySelector("input[name='api_key']");
        const savedModel = modelSelect?.dataset?.savedModel || null;

        function fetchModels(apiKey) {
            if (!apiKey) return;

            console.log('fetchModels');
            fetch("/freescoutgptpro/get-models", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content,
                },
                body: JSON.stringify({ api_key: apiKey }),
            })
            .then(response => response.json())
            .then(data => {
                modelSelect.innerHTML = '<option value="">Select an API model</option>';
                if (data.data) {
                    const models = Object.values(data.data);
                    models.forEach(model => {
                    const option = document.createElement("option");
                    option.value = model.id;
                    option.textContent = model.id;

                    if (model.id === savedModel) {
                    option.selected = true;
                    }

                    modelSelect.appendChild(option);
                    });
                } else {
                    console.log('No models found or invalid data format');
                }
            })
            .catch(error => console.error("Error fetching models:", error));
        }

        if (apiKeyInput?.value) {
            fetchModels(apiKeyInput.value);
        }

        apiKeyInput?.addEventListener("blur", function () {
            fetchModels(this.value);
        });

        // --- Clear Cache Button Handler ---
        $(document).on('click', '.clear-cache-btn', function(e) {
            e.preventDefault();
            var btn = $(this);
            var cacheType = btn.data('cache-type');
            btn.prop('disabled', true);
            var origText = btn.text();
            btn.text('Clearing...');
            fetch('/freescoutgptpro/clear-cache', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                },
                body: JSON.stringify({ cache_type: cacheType })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    window.location.reload();
                } else {
                    alert('Failed clearing cache: ' + (data.error || 'Unknown error'));
                }
            })
            .catch(err => {
                alert('Error clearing cache: ' + err);
            })
            .finally(() => {
                btn.prop('disabled', false);
                btn.text(origText);
            });
        });
    }
});
