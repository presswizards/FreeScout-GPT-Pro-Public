document.addEventListener("DOMContentLoaded", function () {
    const mailboxId = document.getElementById('freescout-gpt-pro-container').dataset.mailboxId;
    const robotIcons = document.querySelectorAll('i.fa-solid.fa-robot');
    robotIcons.forEach(icon => {
        icon.classList.add('fa-fade');
        setTimeout(() => {
            icon.classList.remove('fa-fade');
        }, 3000);
    });

    const handler = new FS.Checkout({
        product_id: '19065',
        plan_id: '31580',
        public_key: 'pk_25feb8abb0fabc990c5ab3d30a94e',
    });

    const lastCheckKey = `gptpro_license_check_${mailboxId}`;
    const lastCheck = localStorage.getItem(lastCheckKey);
    const now = Date.now();
    if (!lastCheck || now - parseInt(lastCheck, 10) > 24 * 60 * 60 * 1000) {
        if (typeof handleLicenseValidation === 'function') {
            handleLicenseValidation();
            localStorage.setItem(lastCheckKey, now.toString());
        }
    }

    function openFreemiusCheckout(trial = false) {
        handler.open({
            licenses: 1,
            // billing_cycle: 'annual',
            billing_cycle_selector: 'responsive_list',
            show_reviews: true,
            trial, // trial: true or false
            purchaseCompleted: (response) => {
                console.log('Purchase completed:', response);
                handleLicenseValidation(null, response.license_key);
            },
            success: (response) => {
                console.log('Checkout closed after successful purchase:', response);
            },
        });
    }

    const buyBtn = document.getElementById("freemius-buy-btn");
    if (buyBtn) {
        buyBtn.addEventListener("click", () => openFreemiusCheckout(false));
    }

    const trialBtn = document.getElementById("freemius-trial-btn");
    if (trialBtn) {
        trialBtn.addEventListener("click", () => openFreemiusCheckout(true));
    }

    // Show freemius-activate form on button click
    const activateBtn = document.getElementById("freemius-activate-btn");
    const activateFormDiv = document.querySelector(".freemius-activate");
    if (activateBtn && activateFormDiv) {
        activateBtn.addEventListener("click", () => {
            activateFormDiv.style.display = "block";
        });
    }

    // License Key Activation Hook
    const licenseForm = document.getElementById('license-form');
    const refreshBtn = document.getElementById('freemius-validate-btn');

    function handleLicenseValidation(e, licenseKey = null) {
        if (e) e.preventDefault();
        const key = licenseKey || document.getElementById('gptpro_license_key')?.value || document.getElementById('gptpro_license_key_data')?.dataset.gptproLicenseKey;
        const msg = document.getElementById('license-message');
        console.log('License element clicked - checking license vars');
        if (!key || !msg) {
            console.log('Missing key or msg element');
            return;
        }
        msg.textContent = '';
        fetch(`/mailbox/${mailboxId}/freescoutgptpro/validate-license`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.getAttribute('content')
            },
            body: JSON.stringify({ gptpro_license_key: key })
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                msg.style.color = 'green';
                msg.textContent = 'Result: License validated successfully. Reloading...';
                setTimeout(() => location.reload(), 2500);
            } else {
                msg.style.color = 'red';
                msg.textContent = 'Result: ' + data.error || 'Result: Issue with license validation, please check your license key.';
                // setTimeout(() => location.reload(), 5000);
            }
        })
        .catch(() => { msg.textContent = 'Error validating license.'; });
    }

    if (licenseForm) {
        console.log('License form submit click event listener added');
        licenseForm.addEventListener('submit', handleLicenseValidation);
    }
    if (refreshBtn) {
        console.log('Refresh btn click event listener added');
        refreshBtn.addEventListener('click', handleLicenseValidation);
    }

    const modelSelect = document.getElementById("model");
    if (modelSelect) {
        const apiKeyInput = document.querySelector("input[name='api_key']");
        const savedModel = modelSelect?.dataset?.savedModel || null;

        function fetchModels(apiKey) {
            if (!apiKey) return;

            console.log('fetchModels');
            fetch("/freescoutgptpro/get-models", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content,
                },
                body: JSON.stringify({ api_key: apiKey }),
            })
            .then(response => response.json())
            .then(data => {
                modelSelect.innerHTML = '<option value="">Select an API model</option>';
                if (data.data) {
                    const models = Object.values(data.data);
                    models.forEach(model => {
                    const option = document.createElement("option");
                    option.value = model.id;
                    option.textContent = model.id;

                    if (model.id === savedModel) {
                    option.selected = true;
                    }

                    modelSelect.appendChild(option);
                    });
                } else {
                    console.log('No models found or invalid data format');
                }
            })
            .catch(error => console.error("Error fetching models:", error));
        }

        if (apiKeyInput?.value) {
            fetchModels(apiKeyInput.value);
        }

        apiKeyInput?.addEventListener("blur", function () {
            fetchModels(this.value);
        });

        // --- Clear Cache Button Handler ---
        $(document).on('click', '.clear-cache-btn', function(e) {
            e.preventDefault();
            var btn = $(this);
            var cacheType = btn.data('cache-type');
            btn.prop('disabled', true);
            var origText = btn.text();
            btn.text('Clearing...');
            fetch('/freescoutgptpro/clear-cache?mailbox=' + mailboxId, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                },
                body: JSON.stringify({ cache_type: cacheType })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    window.location.reload();
                } else {
                    alert('Failed clearing cache: ' + (data.error || 'Unknown error'));
                }
            })
            .catch(err => {
                alert('Error clearing cache: ' + err);
            })
            .finally(() => {
                btn.prop('disabled', false);
                btn.text(origText);
            });
        });
// --- Regenerate Vector Embeds and Content Cache Button Handler ---
$(document).on('click', '#regenerate-embeds-btn', function(e) {
    e.preventDefault();
    var btn = $(this);
    var status = $('#regenerate-embeds-status');
    btn.prop('disabled', true);
    status.text('Regenerating...').show();
    fetch('/freescoutgptpro/generate', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
        },
        body: new URLSearchParams({ mailbox_id: mailboxId, regenerate_only: 1 })
    })
    .then(response => {
        if (response.ok) {
            // Show flash message by reloading (server sets Session::flash)
            window.location.reload();
        } else {
            status.text('Error: ' + response.statusText).show();
            btn.prop('disabled', false);
        }
    })
    .catch(err => {
        status.text('Error: ' + err).show();
        btn.prop('disabled', false);
    });
});
    }
// FreeScout Widget Embed
    window.FreeScoutW = {
        s: {
            color: "#295a85",
            position: "br",
            locale: "en",
            show_categories: "1",
            id: 3539379351,
            category_id: 41
        }
    };

    if (!document.getElementById("freescout-w")) {
        const a = document.createElement("script");
        a.id = "freescout-w";
        a.src = "https://support.presswizards.com/modules/knowledgebase/js/widget.js?v=3666";
        a.async = true;
        document.getElementsByTagName("script")[0].parentNode.insertBefore(a, null);
    }
});
