<?php

return [
    'name' => 'FreeScoutGPTPro'
];
