<?php

namespace Modules\FreeScoutGPTPro\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use App\Thread;
use App\Mailbox;
use Modules\FreeScoutGPTPro\Entities\GPTSettings;

class FreeScoutGPTProController extends Controller
{
    protected $fs;

    public function __construct()
    {
    }

    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index()
    {
        return view('freescoutgptpro::index');
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create()
    {
        return view('freescoutgptpro::create');
    }

    /**
     * Store a newly created resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function store(Request $request)
    {
    }

    /**
     * Show the specified resource.
     * @return Response
     */
    public function show()
    {
        return view('freescoutgptpro::show');
    }

    /**
     * Show the form for editing the specified resource.
     * @return Response
     */
    public function edit()
    {
        return view('freescoutgptpro::edit');
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(Request $request)
    {
    }

    /**
     * Remove the specified resource from storage.
     * @return Response
     */
    public function destroy()
    {
    }

    public function generate(Request $request)
    {
        if (Auth::user() === null) return Response::json(["error" => "Unauthorized"], 401);

        $userQuery = $request->get('query');
        $keep_fssub_cache = now()->addDay();
        $settings = GPTSettings::findOrFail($request->get("mailbox_id"));

        $licenseCheckedKey = 'gptpro_fssub_cachekey' . $settings->mailbox_id;
        if (!Cache::store('file')->has($licenseCheckedKey)) {
            $licenseKey = $settings->gptpro_license_key;
            if ($licenseKey) {
                $licRequest = new \Illuminate\Http\Request(['gptpro_license_key' => $licenseKey]);
                $result = $this->validateLicenseKey($settings->mailbox_id, $licRequest);
                $resultData = $result instanceof \Illuminate\Http\JsonResponse ? $result->getData(true) : [];
                if (empty($resultData['success'])) {
                    // return Response::json(["error" => $resultData['error'] ?? 'License validation failed'], 403);
                    $answerText = $resultData['error'] ?? 'License validation failed';
                    return Response::json([
                        'query' => $userQuery ?? '',
                        'answer' => $answerText
                    ], 200);
                }
                \Log::info('[License key validated successfully]');
                Cache::store('file')->put($licenseCheckedKey, true, $keep_fssub_cache);
            } else {
                // return Response::json(["error" => "License key is missing"], 403);
                $answerText = 'License key is missing';
                return Response::json([
                    'query' => $userQuery ?? '',
                    'answer' => $answerText
                ], 200);
            }
        }

        // Handle deletion of answer if deleteThreadId is set
        $deleteThreadId = $request->get('deleteThreadId');
        $deleteAnswerIndex = $request->get('deleteAnswerIndex');
        if ($deleteThreadId !== null && $deleteAnswerIndex !== null) {
            $thread = Thread::find($deleteThreadId);
            if ($thread !== null && $thread->chatgpt) {
                $answers = json_decode($thread->chatgpt, true);
                if (is_array($answers) && array_key_exists($deleteAnswerIndex, $answers)) {
                    array_splice($answers, $deleteAnswerIndex, 1);
                    $thread->chatgpt = json_encode($answers, JSON_UNESCAPED_UNICODE);
                    $thread->save();
                    return Response::json([
                        'success' => true,
                        'deletedIndex' => $deleteAnswerIndex,
                        'message' => 'Answer deleted successfully.'
                    ], 200);
                } else {
                    return Response::json([
                        'error' => 'Answer index not found.'
                    ], 404);
                }
            } else {
                return Response::json([
                    'error' => 'Thread not found or no answers.'
                ], 404);
            }
        }

        // \Log::info('use_kb_articles setting value:', ['value' => $settings->use_kb_articles]);

        $regenerateOnly = $request->get('regenerate_only', false);

        $articleUrls = array_filter(array_map('trim', preg_split('/\r?\n/', $settings->article_urls ?? '')));
        $articles = [];
        $articleFetchCount = 0;
        if ($articlePrep = $this->refreshSettingsSync($settings)) return $articlePrep;
        $client = new \GuzzleHttp\Client();
        foreach ($articleUrls as $url) {
            $cacheKey = 'gptpro_article_' . md5($url);
            $cacheDays = (int)($settings->cache_article_days ?? 0);
            // \Log::info('ARTICLE CACHE DAYS: '. $cacheDays);
            $cachedArticle = ($cacheDays > 0) ? Cache::store('file')->get($cacheKey) : null;
            // \Log::info('Article cache used! ', ['key' => $cacheKey]);
            $finalText = $cachedArticle;
            if (!$cachedArticle) {
                try {
                    $res = $client->get($url, [
                        'timeout' => config('app.curl_timeout'),
                        'connect_timeout' => config('app.curl_connect_timeout'),
                        'proxy' => config('app.proxy'),
                        'headers' => [
                            'User-Agent' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'
                        ]
                    ]);
                    $body = (string) $res->getBody();
                    $contentType = $res->getHeaderLine('Content-Type');
                    $isText = preg_match('/\.txt$/i', $url) || stripos($contentType, 'text/plain') !== false;
                    if ($isText) {
                        $safeText = htmlspecialchars($body, ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML5);
                        $body = '<!DOCTYPE html><html><head><meta charset="UTF-8"></head><body>' . $safeText . '</body></html>';
                    }
                    $finalText = $this->parseArticleHtml($body);
                    $finalText = mb_substr($finalText, 0, 12000);
                    $articleFetchCount++;
                    if ($cacheDays > 0) {
                        Cache::store('file')->forget($cacheKey . '_embedding');
                        Cache::store('file')->put($cacheKey, $finalText, now()->addDays($cacheDays));
                        // \Log::info('Added article to cache!', ['key' => $cacheKey]);
                        $cacheIndexKey = 'gptpro_article_keys';
                        $keys = Cache::store('file')->get($cacheIndexKey, []);
                        $keys[] = $cacheKey;
                        Cache::store('file')->put($cacheIndexKey, array_unique($keys), now()->addDays($cacheDays));
                        // \Log::info('Added index of article cache key for ' . $cacheDays, ['key' => $cacheKey, 'all_keys' => $keys]);
                    }
                } catch (\Exception $e) {
                    $errorMsg = $e->getMessage();
                    $answerText = $errorMsg ?? 'Error fetching article';
                    return Response::json([
                        'query' => $userQuery ?? '',
                        'answer' => $answerText
                    ], 200);
                }
            }
            // Generate embedding for article text
            $embedding = $this->getArticleEmbedding($finalText, $settings->api_key, $cacheKey, (int)($settings->embedding_cache_days ?? 90));
            $articles[] = [
                'url' => $url,
                'embedding_key' => $cacheKey . '_embedding',
                'embedding' => $embedding,
                'text' => $finalText
            ];
        }
        if ($articleFetchCount > 0) {
            \Log::info("$articleFetchCount articles fetched and parsed");
        }

        // --- KnowledgeBase module integration ---
        if (
            (int) $settings->use_kb_articles === 1 &&
                \Module::isActive('knowledgebase')
        ) {
            $mailbox = \App\Mailbox::find($settings->mailbox_id);
            $kbArticles = \Modules\KnowledgeBase\Entities\KbArticle::where('mailbox_id', $settings->mailbox_id)
                ->where('status', \Modules\KnowledgeBase\Entities\KbArticle::STATUS_PUBLISHED)
                ->get();
            foreach ($kbArticles as $kbArticle) {
                $url = (method_exists($kbArticle, 'urlFrontend') && $mailbox) ? $kbArticle->urlFrontend($mailbox) : '';
                $html = !empty($kbArticle->text) ? $kbArticle->text : '';
                $finalText = $this->parseArticleHtml($html);
                $finalText = mb_substr($finalText, 0, 12000);
                $kbCacheKey = 'gptpro_kb_' . md5($url . $finalText);
                $embedding = $this->getArticleEmbedding($finalText, $settings->api_key, $kbCacheKey, (int)($settings->embedding_cache_days ?? 90));
                // \Log::info('Get KB Article Embedding: ' . $url, ['key' => $kbCacheKey]);
                $articles[] = [
                    'url' => $url,
                    'embedding_key' => $kbCacheKey . '_embedding',
                    'embedding' => $embedding,
                    'text' => $finalText
                ];
            }
        }
        // --- end KnowledgeBase integration ---

        // --- Saved Replies integration ---
        if (
            (int) $settings->use_saved_replies === 1 &&
            \Module::isActive('savedreplies')
        ) {
            $savedReplyClass = 'Modules\\SavedReplies\\Entities\\SavedReply';
            if (class_exists($savedReplyClass)) {
                $savedReplies = $savedReplyClass::where('mailbox_id', $settings->mailbox_id)->orderBy('sort_order')->get();
                foreach ($savedReplies as $savedReply) {
                    $url = 'No URL - Saved Reply Name: ' . $savedReply->name;
                    $body = !empty($savedReply->text) ? $savedReply->text : '';
                    $finalText = $this->parseArticleHtml($body);
                    $finalText = mb_substr($finalText, 0, 12000);
                    // \Log::info('SavedReply Article Parsed: ' . $url . ' ' . $finalText);
                    $srCacheKey = 'gptpro_sr_' . md5($url . $finalText);
                    $embedding = $this->getArticleEmbedding($finalText, $settings->api_key, $srCacheKey, (int)($settings->embedding_cache_days ?? 90));
                    // \Log::info('Get SavedReply Embedding: ' . $url, ['key' => $kbCacheKey]);
                    $articles[] = [
                        'url' => $url,
                        'embedding_key' => $srCacheKey . '_embedding',
                        'embedding' => $embedding,
                        'text' => $finalText
                    ];
                }
            }
        }
        // --- end Saved Replies integration ---

        // If regenerating only, skip the API call and return success
        if ($regenerateOnly) {
            \Session::flash('flash_success_floating', __('Regeneration Complete'));
            return Response::json(['success' => true], 200);
        }

        // --- Query embedding and Cosine Similarity ranking ---
        $userQuery = $request->get('query') ?? '';
        $queryEmbedding = $this->getArticleEmbedding($userQuery, $settings->api_key, 'gptpro_query_' . md5($userQuery), (int)($settings->embedding_cache_days ?? 90));
        $rankedArticles = [];
        foreach ($articles as $article) {
            if (!empty($article['embedding']) && !empty($queryEmbedding)) {
                $similarity = $this->cosineSimilarity($queryEmbedding, $article['embedding']);
            } else {
                $similarity = 0.0;
            }
            $rankedArticles[] = [
                'url' => $article['url'],
                'text' => $article['text'],
                'similarity' => $similarity
            ];
        }
        usort($rankedArticles, function($a, $b) {
            return $b['similarity'] <=> $a['similarity'];
        });
        // --- Set top 5 articles ---
        $topArticles = array_slice($rankedArticles, 0, 5);

        $context = "";
        $customerName = "";
        $conversationSubject = $request->get("conversation_subject");
        if ($settings->client_data_enabled) {
            $context .= "Customer name is: " . $request->get("customer_name") . "\n";
        }
        $context .= "Conversation subject is: $conversationSubject\n";
        $context .= "Customer query: $userQuery\n\n";

        if (empty($topArticles)) {
            $context .= "No relevant articles found.\n";
        } else {
            $context .= "Relevant articles:\n";
            foreach ($topArticles as $i => $article) {
                $context .= "[Article #" . ($i + 1) . "] URL: " . $article['url'] . "\n";
                $context .= (is_string($article['text']) ? $article['text'] : '') . "\n\n";
//            \Log::info('Top Articles Used', ['article' . ($i + 1) . ': ' => $article['url']]);
            }
        }

        // Use modifyPrompt if set otherwise use AI Training Prompt
        $ajax_cmd = $request->get("command");
        if (!empty($ajax_cmd)) {
            $prompt = $ajax_cmd . "\n\n";
        } elseif (isset($settings->start_message) && $settings->start_message) {
            $prompt = $settings->start_message . "\n\n";
        } else {
            $prompt = "Act like a professional customer support agent, and send a concise reply to the customer email.\n\n";
        }
        // \Log::info('GPTPro Training Prompt: ' . json_encode($prompt, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
        
        // AI Content Prompt (RAG)
        if (isset($settings->responses_api_prompt) && $settings->responses_api_prompt) {
            $prompt .= $settings->responses_api_prompt . "\n\n";
        } else {
            $prompt .= "If relevant to the customer's message, refer to the articles included that best answers the user's question, and give detailed answers based on the content of the article, and provide the article URLs so they can reference it themselves as well. If the articles are not relevant, ignore the articles and URLs, and reply with a professional answer that addresses their specific concerns.";
        }
        // \Log::info('GPTPro Full Prompt: ' . json_encode($prompt, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));

        // Use Guzzle to call OpenAI Responses API
        try {
            $guzzle = new \GuzzleHttp\Client();
            $apiKey = $settings->api_key;
            $payload = [
                'model' => is_string($settings->model) ? $settings->model : (is_array($settings->model) ? reset($settings->model) : ''),
                'input' => (string)($prompt . "\n" . $context),
                'max_output_tokens' => (integer) $settings->token_limit
            ];
            // DEBUG API PAYLOAD HERE, Uncomment this next line:
            // \Log::info('GPTPro API Payload: ' . json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
            $jsonPayload = json_encode($payload);
            $response = $guzzle->post('https://api.openai.com/v1/responses', [
                'timeout' => config('app.curl_timeout'),
                'connect_timeout' => config('app.curl_connect_timeout'),
                'proxy' => config('app.proxy'),
                'headers' => [
                    'Authorization' => 'Bearer ' . $apiKey,
                    'Content-Type' => 'application/json',
                ],
                'body' => $jsonPayload,
            ]);
            $data = json_decode($response->getBody(), true);
            // DEBUG API RESPONSE HERE, Uncomment this next line:
            // \Log::info('GPTPro API Response: ' . json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
            if (isset($data['output']) && is_array($data['output'])) {
                foreach ($data['output'] as $item) {
                    if (
                        isset($item['type'], $item['content'][0]['text']) &&
                        $item['type'] === 'message' &&
                        is_string($item['content'][0]['text'])
                    ) {
                        $answerText = trim($item['content'][0]['text'], "\n");
                        break; // Message found, no need to continue looping
                    }
                }
            }
        } catch (\Exception $e) {
            $errorMsg = $e->getMessage();
            $openAiError = '';
            if (method_exists($e, 'getResponse') && $e->getResponse()) {
                $body = (string) $e->getResponse()->getBody();
                $json = json_decode($body, true);
                if (isset($json['error']['message'])) {
                    $openAiError = $json['error']['message'];
                } else {
                    $openAiError = $body;
                }
            }
            $answerText = $openAiError ?: $errorMsg;
            return Response::json([
                'query' => $userQuery ?? '',
                'answer' => $answerText
            ], 200);
        }
        $thread = Thread::find($request->get('thread_id'));
        if ($thread !== null) {
            $answers = $thread->chatgpt ? json_decode($thread->chatgpt, true) : [];
            if ($answers === null) $answers = [];
            $answers[] = $answerText;
            $thread->chatgpt = json_encode($answers, JSON_UNESCAPED_UNICODE);
            $thread->save();
        }
        return Response::json([
            'query' => $userQuery,
            'answer' => $answerText
        ], 200);
    }

    /**
     * Parse article HTML to extract readable text and links.
     */
    private function parseArticleHtml($html)
    {
        if (empty($html)) {
            return '';
        }

        // Normalize: ensure UTF-8 and decode any entities
        $html = html_entity_decode($html, ENT_QUOTES | ENT_HTML5, 'UTF-8');

        libxml_use_internal_errors(true);
        $dom = new \DOMDocument();
        // Force UTF-8 parsing
        if ($dom->loadHTML('<?xml encoding="utf-8" ?>' . $html, LIBXML_NOERROR | LIBXML_NOWARNING)) {
            $xpath = new \DOMXPath($dom);
            $nodes = $xpath->query('/*');
            $text = '';

            foreach ($nodes as $node) {
                // Replace <a> tags with "text: href"
                $aTags = $node->getElementsByTagName('a');
                foreach (iterator_to_array($aTags) as $a) {
                    $linkText = trim($a->textContent);
                    $href = $a->getAttribute('href');
                    if ($linkText && $href) {
                        $replacement = $linkText . ': ' . $href . "\n";
                        $a->parentNode->replaceChild($dom->createTextNode($replacement), $a);
                    }
                }

                // Collect inner content
                $innerHTML = '';
                foreach ($node->childNodes as $child) {
                    $innerHTML .= $dom->saveHTML($child);
                }

                // Strip unwanted elements
                $innerHTML = preg_replace('/<style[\s\S]*?<\/style>/i', '', $innerHTML ?? '');
                $innerHTML = preg_replace('/<script[\s\S]*?<\/script>/i', '', $innerHTML ?? '');
                $plainText = strip_tags($innerHTML);

                // Normalize spacing and entities
                $plainText = html_entity_decode($plainText, ENT_QUOTES | ENT_HTML5, 'UTF-8');
                $plainText = str_replace("\xc2\xa0", ' ', $plainText); // non-breaking space
                $plainText = preg_replace('/[ \t]+/', ' ', $plainText ?? '');
                $plainText = preg_replace('/[\r\n]{2,}/', "\n\n", $plainText ?? '');

                $text .= trim($plainText) . "\n\n";
            }

            libxml_clear_errors();
            return trim($text);
        }

        return '';
    }

    /**
     * Generate and cache OpenAI embedding for a given text.
     * Returns the embedding vector (array) or null on failure.
     */
    private function getArticleEmbedding($text, $apiKey, $cacheKey, $cacheDays = 90)
    {
        if (empty($text) || empty($apiKey)) return null;
        $embeddingCacheKey = $cacheKey . '_embedding';
        if (Cache::store('file')->has($embeddingCacheKey)) {
            // \Log::info('Embedding cache used! ', ['key' => $embeddingCacheKey]);
            return Cache::store('file')->get($embeddingCacheKey);
        }
        try {
            $client = new \GuzzleHttp\Client();
            $response = $client->post('https://api.openai.com/v1/embeddings', [
                'timeout' => config('app.curl_timeout'),
                'connect_timeout' => config('app.curl_connect_timeout'),
                'proxy' => config('app.proxy'),
                'headers' => [
                    'Authorization' => 'Bearer ' . $apiKey,
                    'Content-Type' => 'application/json',
                ],
                'json' => [
                    'model' => 'text-embedding-3-small',
                    'input' => mb_substr($text, 0, 8191), // OpenAI limit
                ],
            ]);
            $data = json_decode($response->getBody(), true);
            if (isset($data['data'][0]['embedding'])) {
                $embedding = $data['data'][0]['embedding'];
                Cache::store('file')->put($embeddingCacheKey, $embedding, now()->addDays($cacheDays));
                $embeddingIndexKey = 'gptpro_embedding_keys';
                $eKeys = Cache::store('file')->get($embeddingIndexKey, []);
                $eKeys[] = $embeddingCacheKey;
                Cache::store('file')->put($embeddingIndexKey, array_unique($eKeys), now()->addDays($cacheDays));
                // \Log::info('Adding index of embedding cache key for ' . $cacheDays . ' days.', ['key' => $embeddingCacheKey, 'all_keys' => $eKeys]);
                return $embedding;
            }
        } catch (\Exception $e) {
            // Log or ignore embedding errors, fallback to no embedding
            return Response::json(['error' => 'Embedding error: ' . $e->getMessage()], 500);
        }
        return null;
    }

    /**
     * Compute cosine similarity between two vectors.
     */
    private function cosineSimilarity($vecA, $vecB)
    {
        if (!is_array($vecA) || !is_array($vecB)) return 0.0;
        if (count($vecA) !== count($vecB)) return 0.0;
        $dot = 0.0;
        $normA = 0.0;
        $normB = 0.0;
        for ($i = 0; $i < count($vecA); $i++) {
            $dot += $vecA[$i] * $vecB[$i];
            $normA += $vecA[$i] * $vecA[$i];
            $normB += $vecB[$i] * $vecB[$i];
        }
        if ($normA == 0.0 || $normB == 0.0) return 0.0;
        return $dot / (sqrt($normA) * sqrt($normB));
    }

    /**
     * Handle AI Edit requests for text editing actions.
     */
    public function aiEdit(Request $request) {
        if (Auth::user() === null) {
            \Log::error('Unauthorized: ' . json_encode($request->all(), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
            return Response::json(["error" => "Unauthorized"], 401);
        }

        $mailbox_id = $request->get("mailbox_id");
        if (!$mailbox_id) {
            \Log::error('No Mailbox ID: ' . json_encode($request->all(), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
            return Response::json(['error' => 'Mailbox ID is required.'], 400);
        }

        $userQuery = $request->get('text');
        $keep_fssub_cache = now()->addDay();
        $settings = GPTSettings::findOrFail($mailbox_id);

        $licenseCheckedKey = 'gptpro_fssub_cachekey' . $settings->mailbox_id;
        if (!Cache::store('file')->has($licenseCheckedKey)) {
            $licenseKey = $settings->gptpro_license_key;
            if ($licenseKey) {
                $licRequest = new \Illuminate\Http\Request(['gptpro_license_key' => $licenseKey]);
                $result = $this->validateLicenseKey($settings->mailbox_id, $licRequest);
                $resultData = $result instanceof \Illuminate\Http\JsonResponse ? $result->getData(true) : [];
                if (empty($resultData['success'])) {
                    $answerText = $resultData['error'] ?? 'License validation failed';
                    return Response::json([
                        'query' => $userQuery ?? '',
                        'answer' => $answerText
                    ], 200);
                }
                \Log::info('[License key validated successfully]');
                Cache::store('file')->put($licenseCheckedKey, true, $keep_fssub_cache);
            } else {
                $answerText = 'License key is missing';
                return Response::json([
                    'query' => $userQuery ?? '',
                    'answer' => $answerText
                ], 200);
            }
        }

        $text = $request->input('text');
        $action = $request->input('action');

        // Get API key and model
        if (!$settings || !$settings->api_key) {
            return Response::json(['error' => 'API key not configured.'], 500);
        }
        $apiKey = $settings->api_key;
        // $model = is_string($settings->model) ? $settings->model : (is_array($settings->model) ? reset($settings->model) : 'gpt-4.1-nano');
        $model = 'gpt-4.1-nano';
        // \Log::info('[Starting API Request] - ' . $text . '\n' . $action);

        // Map action to prompt
        switch ($action) {
            case 'fix_spelling':
                $instruction = "Correct any spelling and grammar mistakes in the following text, but do not change its meaning, send back only the corrected text, and keep line returns and paragraphs intact.";
                break;
            case 'longer':
                $instruction = "Expand and elaborate and send back only the following text making it longer and more detailed. Keep line returns and paragraphs intact as much as possible.";
                break;
            case 'shorter':
                $instruction = "Rewrite and send back only the following text to be shorter and more concise, keeping the main idea. Keep line returns and paragraphs intact as much as possible.";
                break;
            case 'friendlier':
                $instruction = "Rewrite and send back only the following text to sound more friendly and casual, without exclaimation marks. Keep line returns and paragraphs intact as much as possible.";
                break;
            case 'professional':
                $instruction = "Rewrite and send back only the following text to sound more professional and formal. Keep line returns and paragraphs intact as much as possible.";
                break;
            default:
                $instruction = "Polish and send back only the following text as appropriate. Keep line returns and paragraphs intact.";
        }

        // Prepare OpenAI Responses API payload (not Chat API)
        $payload = [
            'model' => $model,
            'instructions' => $instruction,
            'input' =>  $text,
            'max_output_tokens' => (integer) $settings->token_limit,
        ];

        try {
            $client = new \GuzzleHttp\Client();
            $response = $client->post('https://api.openai.com/v1/responses', [
                'timeout' => config('app.curl_timeout'),
                'connect_timeout' => config('app.curl_connect_timeout'),
                'proxy' => config('app.proxy'),
                'headers' => [
                    'Authorization' => 'Bearer ' . $apiKey,
                    'Content-Type' => 'application/json',
                ],
                'json' => $payload,
            ]);
            $data = json_decode($response->getBody(), true);
            // DEBUG API RESPONSE HERE, Uncomment this next line:
            // \Log::info('GPTPro API Response: ' . json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));

            if (isset($data['output']) && is_array($data['output'])) {
                foreach ($data['output'] as $out) {
                    if (
                        isset($out['type']) &&
                        $out['type'] === 'message' &&
                        isset($out['content'][0]['text']) &&
                        is_string($out['content'][0]['text'])
                    ) {
                        $edited = trim($out['content'][0]['text']);
                        return Response::json(['edited' => $edited], 200);
                    }
                }
            }

            return Response::json(['edited' => 'Sorry, no AI response, try again?'], 200);

        } catch (\Exception $e) {
            $errorMsg = $e->getMessage();
            $openAiError = '';
            if (method_exists($e, 'getResponse') && $e->getResponse()) {
                $body = (string) $e->getResponse()->getBody();
                $json = json_decode($body, true);
                if (isset($json['error']['message'])) {
                    $openAiError = $json['error']['message'];
                } else {
                    $openAiError = $body;
                }
            }
            $edited = $openAiError ?: $errorMsg;
            return Response::json(['edited' => $edited], 200);
        }
    }


    public function getAvailableModels(Request $request)
    {
        $apiKey = $request->input('api_key');

        if (!$apiKey) {
            return response()->json(['error' => 'API key is required'], 400);
        }

        $cacheKey = 'openai_models_' . md5($apiKey);

        // Check if models are cached
        if (Cache::store('file')->has($cacheKey)) {
            return response()->json(['data' => Cache::store('file')->get($cacheKey)]);
        }

        try {
            $client = new \GuzzleHttp\Client();
            $response = $client->get('https://api.openai.com/v1/models', [
                'timeout' => config('app.curl_timeout'),
                'connect_timeout' => config('app.curl_connect_timeout'),
                'proxy' => config('app.proxy'),
                'headers' => [
                    'Authorization' => 'Bearer ' . $apiKey,
                    'Accept' => 'application/json',
                ],
            ]);

            $models = json_decode($response->getBody(), true);

            // Filter models by version (o1, o3, o4) and remove older models (like 3.5, 4)
            $filteredModels = array_filter($models['data'], function ($model) {
                // Skip non-chat models like whisper, babbage, tts, etc.
                $nonChatModels = ['search','transcribe', 'realtime', 'whisper', 'babbage', 'davinci', 'curie', 'text-to-speech', 'dall-e', '-audio', 'tts', 'embedding', '2024', '2025'];
                foreach ($nonChatModels as $nonChatModel) {
                    if (strpos($model['id'], $nonChatModel) !== false) {
                        return false;
                    }
                }

                if (strpos($model['id'], 'gpt-4o') !== false || strpos($model['id'], 'gpt-4.5') !== false || strpos($model['id'], 'gpt-4.1') !== false || strpos($model['id'], 'gpt-5') !== false) {
                    return true;
                }

                // Check if model is one of the newer versions (o1, o3, o4)
                if (preg_match('/(o[1-5]{1})/', $model['id'], $matches)) {
                    return true;
                }
                // Skip models that are older (e.g., 'gpt-3.5', 'gpt-4')
                if (strpos($model['id'], 'gpt-3.5') !== false || strpos($model['id'], 'gpt-4-') !== false) {
                    return false;
                }

                return false;
            });

            // Sort filtered models alphabetically by 'id'
            usort($filteredModels, function($a, $b) {
                return strcmp($a['id'], $b['id']);
            });

            // Cache filtered models for 10 minutes
            Cache::store('file')->put($cacheKey, $filteredModels, now()->addMinutes(10));

            return response()->json(['data' => $filteredModels]);
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function answers(Request $request)
    {
        if (Auth::user() === null) return Response::json(["error" => "Unauthorized"], 401);
        $conversation = $request->query('conversation');
        $threads = Thread::where("conversation_id", $conversation)->get();
        $result = [];
        foreach ($threads as $thread) {
            if ($thread->chatgpt !== "{}" && $thread->chatgpt !== null) {
                $answers = [];
                $answers_text = json_decode($thread->chatgpt, true);
                if ($answers_text === null) continue;
                foreach ($answers_text as $answer_text) {
                    array_push($answers, $answer_text);
                }
                $answer = ["thread" => $thread->id, "answers" => $answers];
                array_push($result, $answer);
            }
        }
        return Response::json(["answers" => $result], 200);
    }

    public function checkIsEnabled(Request $request)
    {
        $settings = GPTSettings::find($request->query("mailbox"));
        if (empty($settings)) {
            return Response::json(['enabled' => false], 200);
        }
        return Response::json(['enabled' => $settings['enabled']], 200);
    }

    public function settings($mailbox_id)
    {
        if (Auth::user() === null) return Response::json(["error" => "Unauthorized"], 401);

        $mailbox = Mailbox::findOrFail($mailbox_id);

        // Fetch settings from DB
        $settings = GPTSettings::where('mailbox_id', $mailbox_id)->first();
        $settings = $settings ? $settings->toArray() : [];

        if (empty($settings)) {
            $settings['mailbox_id'] = $mailbox_id;
            $settings['enabled'] = false;
            $settings['api_key'] = "";
            $settings['token_limit'] = "";
            $settings['start_message'] = "";
            $settings['responses_api_prompt'] = "";
            $settings['model'] = "";
            $settings['client_data_enabled'] = false;
            $settings['use_kb_articles'] = false;
            $settings['cache_article_days'] = 30;
            $settings['embedding_cache_days'] = 90;
            $settings['use_kb_articles'] = false;
            $settings['use_saved_replies'] = false;
        } else {
            if (!isset($settings['use_kb_articles'])) {
                $settings['use_kb_articles'] = false;
            }
            if (!isset($settings['use_saved_replies'])) {
                $settings['use_saved_replies'] = false;
            }
        }

        return view('freescoutgptpro::settings', [
            'mailbox'   => $mailbox,
            'settings'  => $settings
        ]);
    }

    public function saveSettings($mailbox_id, Request $request)
    {
        if (Auth::user() === null) return Response::json(["error" => "Unauthorized"], 401);

        GPTSettings::updateOrCreate(
            ['mailbox_id' => $mailbox_id],
            [
                'api_key' => $request->get("api_key"),
                'enabled' => isset($_POST['gpt_enabled']),
                'token_limit' => $request->get('token_limit'),
                'start_message' => $request->get('start_message'),
                'model' => $request->get('model'),
                'client_data_enabled' => isset($_POST['show_client_data_enabled']),
                'article_urls' => $request->get('article_urls'),
                'responses_api_prompt' => $request->get('responses_api_prompt'),
                'use_kb_articles' => isset($_POST['use_kb_articles']),
                'use_saved_replies' => isset($_POST['use_saved_replies']),
                'cache_article_days' => $request->get('cache_article_days', 30),
                'embedding_cache_days' => $request->get('embedding_cache_days', 90),
                'auto_generate' => $request->has('auto_generate'),
            ]
        );
        \Session::flash('flash_success_floating', __('Settings updated'));
        return redirect()->route('freescoutgptpro.settings', ['mailbox_id' => $mailbox_id]);
    }

    public function refreshSettingsSync($settings = null)
    {
        if (empty($settings)) {
            \Log::info('Settings is empty, exiting');
            return Response::json(["error" => __("Mailbox settings were not found.")], 404);
        }
        // \Log::info('Checking settings...');
        if (empty($settings->gptpro_license_key)) {
            \Log::error('Invalid settings error 1');
            return Response::json(["error" => __("Invalid settings check...")], 403);
        }
        if (!preg_match('/^[0-9a-f]{8}-?[0-9a-f]{4}-?4[0-9a-f]{3}-?[89ab][0-9a-f]{3}-?[0-9a-f]{12}$/i', $settings->gptpro_fs_uuid ?? '')) {
            \Log::error('Invalid settings error 2');
            return Response::json(["error" => __("Invalid settings check...")], 403);
        }
        if (!empty($settings->gptpro_license_expiration) && strtolower($settings->gptpro_license_expiration) !== 'lifetime') {
            try {
                $now = new \DateTime();
                $expiresAt = new \DateTime($settings->gptpro_license_expiration);
                if ($now > $expiresAt) {
                \Log::error('Invalid settings error 3');
                    return Response::json(["error" => __("Invalid settings check...")], 403);
                }
            } catch (\Exception $e) {
                \Log::error('Invalid settings exception: ' . $e->getMessage());
                return Response::json(["error" => __("Invalid settings check...")], 403);
            }
        }
        return null;
    }

    /**
     * Clear cache for articles or embeddings.
     */
    public function clearCache(Request $request)
    {
        if (Auth::user() === null) return Response::json(["error" => "Unauthorized"], 401);
        $type = $request->input('cache_type');
        $cleared = 0;
        $settings = GPTSettings::find($request->query("mailbox"));
        if ($cachePrep = $this->refreshSettingsSync($settings)) return $cachePrep;

        if ($type === 'article') {
            // Clear all tracked article cache keys using the correct store
            $keys = Cache::store('file')->get('gptpro_article_keys', []);
            foreach ($keys as $key) {
                Cache::store('file')->forget($key);
                $cleared++;
            }
            Cache::store('file')->forget('gptpro_article_keys');
            \Session::flash('flash_success_floating', __('Article cache cleared: :count entries removed', ['count' => $cleared]));
        } elseif ($type === 'embedding') {
            // Clear all tracked embedding cache keys using the correct store
            $keys = Cache::store('file')->get('gptpro_embedding_keys', []);
            foreach ($keys as $key) {
                Cache::store('file')->forget($key);
                $cleared++;
            }
            Cache::store('file')->forget('gptpro_embedding_keys');
            \Session::flash('flash_success_floating', __('Embeddings cache cleared: :count entries removed', ['count' => $cleared]));
        } else {
            return Response::json(["error" => "Invalid cache type"], 400);
        }
        return Response::json(["success" => true, "cleared" => $cleared]);
    }

    /**
     * Validate license key via Freemius API for SaaS product.
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function validateLicenseKey($mailbox_id, Request $request)
    {
        $license_key = $request->input('gptpro_license_key');
        $activate_new_license = false;
        // \Log::info("Debug Freemius license activation: " . $license_key);

        $mailbox = Mailbox::findOrFail($mailbox_id);

        if (!$license_key) {
            return response()->json(['success' => false, 'error' => 'License key is missing from submission.'], 400);
        }

        try {
            $settings = GPTSettings::where('mailbox_id', $mailbox_id)->first();

            if (!empty($settings) && !empty($settings->gptpro_license_key)) {
                // Check if the license key is already set
                if ($settings->gptpro_license_key !== $license_key) {
                    $activate_new_license = true;
                }
            }
            // Generate or reuse UUIDv4
            if (!empty($settings) && !empty($settings->gptpro_fs_uuid)) {
                $fs_uuid = $settings->gptpro_fs_uuid;
            } else {
                $bytes = random_bytes(16);
                $bytes[6] = chr((ord($bytes[6]) & 0x0f) | 0x40); // Version 4
                $bytes[8] = chr((ord($bytes[8]) & 0x3f) | 0x80); // Variant 10
                $fs_uuid = bin2hex($bytes);
            }

            // If install info doesn't exist or we're trying a new license key, activate
            if ($activate_new_license || empty($settings) || empty($settings->gptpro_install_id) || empty($settings->gptpro_install_api_token)) {
                 \Log::info("Initiating Freemius license activation");
                $curl = curl_init();
                $postData = [
                    'uid' => $fs_uuid,
                    'license_key' => $license_key,
                    'url' => request()->getHost(),
                    'title' => config('app.name')
                ];

                $fs_activation_endpoint = 'https://api.freemius.com/v1/products/19065/licenses/activate.json?uid=' . $fs_uuid . '&license_key=' . urlencode($license_key);
                curl_setopt_array($curl, [
                    CURLOPT_URL => $fs_activation_endpoint,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_CUSTOMREQUEST => "POST",
                    CURLOPT_POSTFIELDS => json_encode($postData),
                    CURLOPT_HTTPHEADER => [
                        'Content-Type: application/json'
                    ]
                ]);

                $responseData = curl_exec($curl);
                $statusCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
                $err = curl_error($curl);
                curl_close($curl);

                if ($err) {
                    \Log::error("Freemius API cURL Error: " . $err);
                    return response()->json(['success' => false, 'error' => 'Connection error: ' . $err], 500);
                }

                $response = json_decode($responseData);

                if (!is_object($response)) {
                    \Log::error('Freemius API returned invalid JSON response');
                    return response()->json(['success' => false, 'error' => 'Invalid API response'], 500);
                }

                if (!empty($response->error)) {
                    $error = $response->error->message ?? 'Unknown API error';
                    \Log::error('Freemius license activation error: ' . $error);
                    return response()->json(['success' => false, 'error' => $error], 400);
                }

                if ($statusCode !== 200) {
                    \Log::error('Freemius API returned non-200 status code: ' . $statusCode);
                    return response()->json(['success' => false, 'error' => 'API error: HTTP ' . $statusCode], 400);
                }

                if (!isset($response->install_id) || !isset($response->install_api_token)) {
                    \Log::error('Freemius API response missing required fields');
                    return response()->json(['success' => false, 'error' => 'Invalid API response: missing installation data'], 400);
                }

                // Save successful activation data
                GPTSettings::updateOrCreate(
                    ['mailbox_id' => $mailbox_id],
                    [
                        'gptpro_license_key' => $license_key,
                        'gptpro_fs_uuid' => $fs_uuid,
                        'gptpro_install_id' => $response->install_id,
                        'gptpro_install_api_token' => $response->install_api_token,
                    ]
                );
                \Session::flash('flash_success_floating', __('License activated and saved successfully.'));
                // return response()->json(['success' => true]);
            }
        } catch (\Exception $e) {
            \Log::error('Freemius license validation exception: ' . $e->getMessage());
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }

        try {
            // Then also: Validate existing installation to get expiration date
            // Fetch Saved settings
            $settings = GPTSettings::where('mailbox_id', $mailbox_id)->first();

            $install_id = !empty($settings) ? $settings->gptpro_install_id : '';
            $uuid       = !empty($settings) ? $settings->gptpro_fs_uuid : '';
            $license    = !empty($settings) ? $settings->gptpro_license_key : '';

            $fs_validate_endpoint = "https://api.freemius.com/v1/products/19065/installs/{$install_id}/license.json?uid={$uuid}&license_key=" . urlencode($license);

            $curl = curl_init();
            curl_setopt_array($curl, [
                CURLOPT_URL => $fs_validate_endpoint,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_CUSTOMREQUEST => "GET",
                CURLOPT_HTTPHEADER => [
                    'Authorization: Bearer ' . $settings->gptpro_install_api_token
                ]
            ]);

            $responseData = curl_exec($curl);
            $statusCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
            $err = curl_error($curl);
            curl_close($curl);

            if ($err) {
                \Log::error("Freemius API cURL Error during validation: " . $err);
                return response()->json(['success' => false, 'error' => 'Connection error: ' . $err], 500);
            }

            $response = json_decode($responseData);

            if (!is_object($response)) {
                \Log::error('Freemius API returned invalid JSON response during validation');
                return response()->json(['success' => false, 'error' => 'Invalid API response'], 500);
            }

            // Handle unauthorized or not found errors by triggering reactivation
            if ( $statusCode === 401 || $statusCode === 403 || $statusCode === 404 || (!empty($response->is_cancelled) && $response->is_cancelled === true) ) {
                \Log::error('FreeScout GPT Pro License cancelled, not found, or unauthorized: clearing install ID data for reactivation');
                GPTSettings::updateOrCreate(
                    ['mailbox_id' => $mailbox_id],
                    [
                        'gptpro_install_id' => null,
                        'gptpro_install_api_token' => null
                    ]
                );
                \Session::flash('flash_error_floating', __('License was cancelled or requires reactivation.'));
                return response()->json(['success' => false, 'error' => 'License was cancelled or requires reactivation, please retry.'], 401);
            }

            if (!empty($response->error)) {
                $error = $response->error->message ?? 'Unknown API error';
                \Log::error('Freemius installation validation error: ' . $error);
                return response()->json(['success' => false, 'error' => $error], 400);
            }

            if (!empty($response->expiration)) {
                $now = new \DateTime();
                $expiresAt = new \DateTime($response->expiration);

                if ($now > $expiresAt) {
                    \Log::error('Freemius license has expired.', [
                        'mailbox_id' => $mailbox_id,
                        'expired_at' => $response->expiration,
                    ]);
                GPTSettings::updateOrCreate(
                    ['mailbox_id' => $mailbox_id],
                    [
                        'gptpro_install_id' => null,
                        'gptpro_install_api_token' => null
                    ]
                );
                \Session::flash('flash_error_floating', __('License has expired. Please renew or activate a valid license.'));
                return response()->json(['success' => false, 'error' => 'License has expired. Please renew or activate a valid license.'], 401);
                }
            }

            if ($statusCode !== 200) {
                \Log::error('Freemius API returned non-200 status code during validation: ' . $statusCode);
                return response()->json(['success' => false, 'error' => 'API error: HTTP ' . $statusCode], 400);
            }

            if (!isset($response->activated) || $response->activated < 1) {
                \Log::error('Freemius license is not active');
                return response()->json(['success' => false, 'error' => 'License has not been actived yet? Retry activating the license or contact support.'], 400);
            }

            // Save successful refresh data
            GPTSettings::updateOrCreate(
                ['mailbox_id' => $mailbox_id],
                [
                    'gptpro_license_expiration' => $response->expiration ?? 'Lifetime',
                ]
            );

            // Commenting out flash because it runs on settings load now as well, once per day
            // Moved up above to run on Activation only
            // \Session::flash('flash_success_floating', __('License validated and saved successfully.'));
            return response()->json(['success' => true]);

        } catch (\Exception $e) {
            \Log::error('Freemius license validation exception: ' . $e->getMessage());
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }
}
