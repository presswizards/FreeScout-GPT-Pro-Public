<?php

namespace Modules\FreeScoutGPTPro\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use App\Thread;
use App\Mailbox;
use Modules\FreeScoutGPTPro\Entities\GPTSettings;

class FreeScoutGPTProController extends Controller
{
    protected $fs;
    protected $defaultOpenAiBaseUrl = 'https://api.openai.com';
    protected $lastEmbeddingError = null;

    public function __construct()
    {
    }

    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index()
    {
        return view('freescoutgptpro::index');
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create()
    {
        return view('freescoutgptpro::create');
    }

    /**
     * Store a newly created resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function store(Request $request)
    {
    }

    /**
     * Show the specified resource.
     * @return Response
     */
    public function show()
    {
        return view('freescoutgptpro::show');
    }

    /**
     * Show the form for editing the specified resource.
     * @return Response
     */
    public function edit()
    {
        return view('freescoutgptpro::edit');
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(Request $request)
    {
    }

    /**
     * Remove the specified resource from storage.
     * @return Response
     */
    public function destroy()
    {
    }

    public function generate(Request $request)
    {
        if (Auth::user() === null) return Response::json(["error" => "Unauthorized"], 401);

        $userQuery = $request->get('query');
        $keep_fssub_cache = now()->addDay();
        $settings = GPTSettings::findOrFail($request->get("mailbox_id"));

        $licenseCheckedKey = 'gptpro_fssub_cachekey' . $settings->mailbox_id;
        if (!Cache::store('file')->has($licenseCheckedKey)) {
            $licenseKey = $settings->gptpro_license_key;
            if ($licenseKey) {
                $licRequest = new \Illuminate\Http\Request(['gptpro_license_key' => $licenseKey]);
                $result = $this->validateLicenseKey($settings->mailbox_id, $licRequest);
                $resultData = $result instanceof \Illuminate\Http\JsonResponse ? $result->getData(true) : [];
                if (empty($resultData['success'])) {
                    // return Response::json(["error" => $resultData['error'] ?? 'License validation failed'], 403);
                    $answerText = $resultData['error'] ?? 'License validation failed';
                    return Response::json([
                        'query' => $userQuery ?? '',
                        'answer' => $answerText
                    ], 200);
                }
                \Log::info('[License key validated successfully]');
                Cache::store('file')->put($licenseCheckedKey, true, $keep_fssub_cache);
            } else {
                // return Response::json(["error" => "License key is missing"], 403);
                $answerText = 'License key is missing';
                return Response::json([
                    'query' => $userQuery ?? '',
                    'answer' => $answerText
                ], 200);
            }
        }

        // Handle deletion of answer if deleteThreadId is set
        $deleteThreadId = $request->get('deleteThreadId');
        $deleteAnswerIndex = $request->get('deleteAnswerIndex');
        if ($deleteThreadId !== null && $deleteAnswerIndex !== null) {
            $thread = Thread::find($deleteThreadId);
            if ($thread !== null && $thread->chatgpt) {
                $answers = json_decode($thread->chatgpt, true);
                if (is_array($answers) && array_key_exists($deleteAnswerIndex, $answers)) {
                    array_splice($answers, $deleteAnswerIndex, 1);
                    $thread->chatgpt = json_encode($answers, JSON_UNESCAPED_UNICODE);
                    $thread->save();
                    return Response::json([
                        'success' => true,
                        'deletedIndex' => $deleteAnswerIndex,
                        'message' => 'Answer deleted successfully.'
                    ], 200);
                } else {
                    return Response::json([
                        'error' => 'Answer index not found.'
                    ], 404);
                }
            } else {
                return Response::json([
                    'error' => 'Thread not found or no answers.'
                ], 404);
            }
        }

        // \Log::info('use_kb_articles setting value:', ['value' => $settings->use_kb_articles]);

        $regenerateOnly = $request->get('regenerate_only', false);

        $this->lastEmbeddingError = null;
        $articleUrls = array_filter(array_map('trim', preg_split('/\r?\n/', $settings->article_urls ?? '')));
        $articles = [];
        $articleFetchCount = 0;
        $embeddingConfig = $this->getEmbeddingApiConfig($settings);
        if ($articlePrep = $this->refreshSettingsSync($settings)) return $articlePrep;
        $client = new \GuzzleHttp\Client();
        foreach ($articleUrls as $url) {
            $cacheKey = 'gptpro_article_' . md5($url);
            $cacheDays = (int)($settings->cache_article_days ?? 0);
            // \Log::info('ARTICLE CACHE DAYS: '. $cacheDays);
            $cachedArticle = ($cacheDays > 0) ? Cache::store('file')->get($cacheKey) : null;
            // \Log::info('Article cache used! ', ['key' => $cacheKey]);
            $finalText = $cachedArticle;
            if (!$cachedArticle) {
                try {
                    $res = $client->get($url, [
                        'timeout' => config('app.curl_timeout'),
                        'connect_timeout' => config('app.curl_connect_timeout'),
                        'proxy' => config('app.proxy'),
                        'headers' => [
                            'User-Agent' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'
                        ]
                    ]);
                    $body = (string) $res->getBody();
                    $contentType = $res->getHeaderLine('Content-Type');
                    $isText = preg_match('/\.txt$/i', $url) || stripos($contentType, 'text/plain') !== false;
                    if ($isText) {
                        $safeText = htmlspecialchars($body, ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML5);
                        $body = '<!DOCTYPE html><html><head><meta charset="UTF-8"></head><body>' . $safeText . '</body></html>';
                    }
                    $finalText = $this->parseArticleHtml($body);
                    $finalText = mb_substr($finalText, 0, 12000);
                    $articleFetchCount++;
                    if ($cacheDays > 0) {
                        Cache::store('file')->forget($cacheKey . '_embedding');
                        Cache::store('file')->put($cacheKey, $finalText, now()->addDays($cacheDays));
                        // \Log::info('Added article to cache!', ['key' => $cacheKey]);
                        $cacheIndexKey = 'gptpro_article_keys';
                        $keys = Cache::store('file')->get($cacheIndexKey, []);
                        $keys[] = $cacheKey;
                        Cache::store('file')->put($cacheIndexKey, array_unique($keys), now()->addDays($cacheDays));
                        // \Log::info('Added index of article cache key for ' . $cacheDays, ['key' => $cacheKey, 'all_keys' => $keys]);
                    }
                } catch (\Exception $e) {
                    $errorMsg = $e->getMessage();
                    $answerText = $errorMsg ?? 'Error fetching article';
                    return Response::json([
                        'query' => $userQuery ?? '',
                        'answer' => $answerText
                    ], 200);
                }
            }
            // Generate embedding for article text
            $embedding = $this->getArticleEmbedding($finalText, $embeddingConfig['api_key'], $cacheKey, (int)($settings->embedding_cache_days ?? 90), $embeddingConfig['endpoint'], $embeddingConfig['model']);
            if (!empty($this->lastEmbeddingError)) {
                return Response::json([
                    'query' => $userQuery ?? '',
                    'answer' => $this->lastEmbeddingError,
                ], 200);
            }
            $articles[] = [
                'url' => $url,
                'embedding_key' => $cacheKey . '_embedding',
                'embedding' => $embedding,
                'text' => $finalText
            ];
        }
        if ($articleFetchCount > 0) {
            \Log::info("$articleFetchCount articles fetched and parsed");
        }

        // --- KnowledgeBase module integration ---
        if (
            (int) $settings->use_kb_articles === 1 &&
                \Module::isActive('knowledgebase')
        ) {
            $mailbox = \App\Mailbox::find($settings->mailbox_id);
            $kbArticles = \Modules\KnowledgeBase\Entities\KbArticle::where('mailbox_id', $settings->mailbox_id)
                ->where('status', \Modules\KnowledgeBase\Entities\KbArticle::STATUS_PUBLISHED)
                ->get();
            foreach ($kbArticles as $kbArticle) {
                $url = (method_exists($kbArticle, 'urlFrontend') && $mailbox) ? $kbArticle->urlFrontend($mailbox) : '';
                $html = !empty($kbArticle->text) ? $kbArticle->text : '';
                $finalText = $this->parseArticleHtml($html);
                $finalText = mb_substr($finalText, 0, 12000);
                $kbCacheKey = 'gptpro_kb_' . md5($url . $finalText);
                $embedding = $this->getArticleEmbedding($finalText, $embeddingConfig['api_key'], $kbCacheKey, (int)($settings->embedding_cache_days ?? 90), $embeddingConfig['endpoint'], $embeddingConfig['model']);
                if (!empty($this->lastEmbeddingError)) {
                    return Response::json([
                        'query' => $userQuery ?? '',
                        'answer' => $this->lastEmbeddingError,
                    ], 200);
                }
                // \Log::info('Get KB Article Embedding: ' . $url, ['key' => $kbCacheKey]);
                $articles[] = [
                    'url' => $url,
                    'embedding_key' => $kbCacheKey . '_embedding',
                    'embedding' => $embedding,
                    'text' => $finalText
                ];
            }
        }
        // --- end KnowledgeBase integration ---

        // --- Saved Replies integration ---
        if (
            (int) $settings->use_saved_replies === 1 &&
            \Module::isActive('savedreplies')
        ) {
            $savedReplyClass = 'Modules\\SavedReplies\\Entities\\SavedReply';
            if (class_exists($savedReplyClass)) {
                $savedReplies = $savedReplyClass::where('mailbox_id', $settings->mailbox_id)->orderBy('sort_order')->get();
                foreach ($savedReplies as $savedReply) {
                    $url = 'No URL - Saved Reply Name: ' . $savedReply->name;
                    $body = !empty($savedReply->text) ? $savedReply->text : '';
                    $finalText = $this->parseArticleHtml($body);
                    $finalText = mb_substr($finalText, 0, 12000);
                    // \Log::info('SavedReply Article Parsed: ' . $url . ' ' . $finalText);
                    $srCacheKey = 'gptpro_sr_' . md5($url . $finalText);
                    $embedding = $this->getArticleEmbedding($finalText, $embeddingConfig['api_key'], $srCacheKey, (int)($settings->embedding_cache_days ?? 90), $embeddingConfig['endpoint'], $embeddingConfig['model']);
                    if (!empty($this->lastEmbeddingError)) {
                        return Response::json([
                            'query' => $userQuery ?? '',
                            'answer' => $this->lastEmbeddingError,
                        ], 200);
                    }
                    // \Log::info('Get SavedReply Embedding: ' . $url, ['key' => $kbCacheKey]);
                    $articles[] = [
                        'url' => $url,
                        'embedding_key' => $srCacheKey . '_embedding',
                        'embedding' => $embedding,
                        'text' => $finalText
                    ];
                }
            }
        }
        // --- end Saved Replies integration ---

        // If regenerating only, skip the API call and return success
        if ($regenerateOnly) {
            \Session::flash('flash_success_floating', __('Regeneration Complete'));
            return Response::json(['success' => true], 200);
        }

        // --- Query embedding and Cosine Similarity ranking ---
        $userQuery = $request->get('query') ?? '';
        $queryEmbedding = $this->getArticleEmbedding($userQuery, $embeddingConfig['api_key'], 'gptpro_query_' . md5($userQuery), (int)($settings->embedding_cache_days ?? 90), $embeddingConfig['endpoint'], $embeddingConfig['model']);
        if (!empty($this->lastEmbeddingError)) {
            return Response::json([
                'query' => $userQuery ?? '',
                'answer' => $this->lastEmbeddingError,
            ], 200);
        }
        $rankedArticles = [];
        foreach ($articles as $article) {
            if (!empty($article['embedding']) && !empty($queryEmbedding)) {
                $similarity = $this->cosineSimilarity($queryEmbedding, $article['embedding']);
            } else {
                $similarity = 0.0;
            }
            $rankedArticles[] = [
                'url' => $article['url'],
                'text' => $article['text'],
                'similarity' => $similarity
            ];
        }
        usort($rankedArticles, function($a, $b) {
            return $b['similarity'] <=> $a['similarity'];
        });
        // --- Set top 5 articles ---
        $topArticles = array_slice($rankedArticles, 0, 5);

        $context = "";
        $customerName = "";
        $conversationSubject = $request->get("conversation_subject");
        if ($settings->client_data_enabled) {
            $context .= "Customer name is: " . $request->get("customer_name") . "\n";
        }
        $context .= "Conversation subject is: $conversationSubject\n";
        $context .= "Customer query: $userQuery\n\n";

        if (empty($topArticles)) {
            $context .= "No relevant articles found.\n";
        } else {
            $context .= "Relevant articles:\n";
            foreach ($topArticles as $i => $article) {
                $context .= "[Article #" . ($i + 1) . "] URL: " . $article['url'] . "\n";
                $context .= (is_string($article['text']) ? $article['text'] : '') . "\n\n";
//            \Log::info('Top Articles Used', ['article' . ($i + 1) . ': ' => $article['url']]);
            }
        }

        // Use modifyPrompt if set otherwise use AI Training Prompt
        $ajax_cmd = $request->get("command");
        if (!empty($ajax_cmd)) {
            $prompt = $ajax_cmd . "\n\n";
        } elseif (isset($settings->start_message) && $settings->start_message) {
            $prompt = $settings->start_message . "\n\n";
        } else {
            $prompt = "Act like a professional customer support agent, and send a concise reply to the customer email.\n\n";
        }
        // \Log::info('GPTPro Training Prompt: ' . json_encode($prompt, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
        
        // AI Content Prompt (RAG)
        if (isset($settings->responses_api_prompt) && $settings->responses_api_prompt) {
            $prompt .= $settings->responses_api_prompt . "\n\n";
        } else {
            $prompt .= "If relevant to the customer's message, refer to the articles included that best answers the user's question, and give detailed answers based on the content of the article, and provide the article URLs so they can reference it themselves as well. If the articles are not relevant, ignore the articles and URLs, and reply with a professional answer that addresses their specific concerns.";
        }
        // \Log::info('GPTPro Full Prompt: ' . json_encode($prompt, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));

        $answerText = ''; // Initialize to prevent undefined variable errors
        $payload = [];
        $targetEndpoint = '';
        try {
            $guzzle = new \GuzzleHttp\Client();
            $generationConfig = $this->getGenerationApiConfig($settings);
            if (empty($generationConfig['api_key'])) {
                return Response::json([
                    'query' => $userQuery ?? '',
                    'answer' => 'API key is missing for the selected provider.'
                ], 200);
            }
            if ($generationConfig['gateway_enabled'] && empty($generationConfig['endpoint'])) {
                return Response::json([
                    'query' => $userQuery ?? '',
                    'answer' => 'Gateway base URL is missing or invalid.'
                ], 200);
            }

            if ($generationConfig['gateway_enabled']) {
                $payload = [
                    'model' => is_string($settings->model) ? $settings->model : (is_array($settings->model) ? reset($settings->model) : ''),
                    'messages' => [
                        [
                            'role' => 'system',
                            'content' => trim($prompt),
                        ],
                        [
                            'role' => 'user',
                            'content' => trim($context),
                        ],
                    ],
                    'max_tokens' => (integer) $settings->token_limit,
                ];
                $targetEndpoint = $generationConfig['endpoint'];
                $response = $guzzle->post($generationConfig['endpoint'], [
                    'timeout' => config('app.curl_timeout'),
                    'connect_timeout' => config('app.curl_connect_timeout'),
                    'proxy' => config('app.proxy'),
                    'headers' => [
                        'Authorization' => 'Bearer ' . $generationConfig['api_key'],
                        'Content-Type' => 'application/json',
                    ],
                    'json' => $payload,
                ]);
            } else {
                $payload = [
                    'model' => is_string($settings->model) ? $settings->model : (is_array($settings->model) ? reset($settings->model) : ''),
                    'input' => (string)($prompt . "\n" . $context),
                    'max_output_tokens' => (integer) $settings->token_limit
                ];
                $targetEndpoint = $generationConfig['endpoint'];
                $jsonPayload = json_encode($payload);
                $response = $guzzle->post($generationConfig['endpoint'], [
                    'timeout' => config('app.curl_timeout'),
                    'connect_timeout' => config('app.curl_connect_timeout'),
                    'proxy' => config('app.proxy'),
                    'headers' => [
                        'Authorization' => 'Bearer ' . $generationConfig['api_key'],
                        'Content-Type' => 'application/json',
                    ],
                    'body' => $jsonPayload,
                ]);
            }

            $data = json_decode($response->getBody(), true);

            if ($generationConfig['gateway_enabled']) {
                $answerText = $this->extractChatCompletionsText($data);
                if ($answerText === '') {
                    $answerText = 'Error: Gateway response did not contain a valid message. Full response: ' . json_encode($data);
                }
            } else {
                $answerText = $this->extractResponsesApiText($data);
            }
        } catch (\Exception $e) {
            $answerText = $this->buildApiErrorMessage($e, 'generate', [
                'gateway_enabled' => !empty($generationConfig['gateway_enabled']),
                'endpoint' => $targetEndpoint,
                'payload' => $this->sanitizePayloadForLog($payload),
            ]);
            return Response::json([
                'query' => $userQuery ?? '',
                'answer' => $answerText
            ], 200);
        }
        $thread = Thread::find($request->get('thread_id'));
        if ($thread !== null) {
            $answers = $thread->chatgpt ? json_decode($thread->chatgpt, true) : [];
            if ($answers === null) $answers = [];
            $answers[] = $answerText;
            $thread->chatgpt = json_encode($answers, JSON_UNESCAPED_UNICODE);
            $thread->save();
        }
        return Response::json([
            'query' => $userQuery,
            'answer' => $answerText
        ], 200);
    }

    /**
     * Parse article HTML to extract readable text and links.
     */
    private function parseArticleHtml($html)
    {
        if (empty($html)) {
            return '';
        }

        // Normalize: ensure UTF-8 and decode any entities
        $html = html_entity_decode($html, ENT_QUOTES | ENT_HTML5, 'UTF-8');

        libxml_use_internal_errors(true);
        $dom = new \DOMDocument();
        // Force UTF-8 parsing
        if ($dom->loadHTML('<?xml encoding="utf-8" ?>' . $html, LIBXML_NOERROR | LIBXML_NOWARNING)) {
            $xpath = new \DOMXPath($dom);
            $nodes = $xpath->query('/*');
            $text = '';

            foreach ($nodes as $node) {
                // Replace <a> tags with "text: href"
                $aTags = $node->getElementsByTagName('a');
                foreach (iterator_to_array($aTags) as $a) {
                    $linkText = trim($a->textContent);
                    $href = $a->getAttribute('href');
                    if ($linkText && $href) {
                        $replacement = $linkText . ': ' . $href . "\n";
                        $a->parentNode->replaceChild($dom->createTextNode($replacement), $a);
                    }
                }

                // Collect inner content
                $innerHTML = '';
                foreach ($node->childNodes as $child) {
                    $innerHTML .= $dom->saveHTML($child);
                }

                // Strip unwanted elements
                $innerHTML = preg_replace('/<style[\s\S]*?<\/style>/i', '', $innerHTML ?? '');
                $innerHTML = preg_replace('/<script[\s\S]*?<\/script>/i', '', $innerHTML ?? '');
                $plainText = strip_tags($innerHTML);

                // Normalize spacing and entities
                $plainText = html_entity_decode($plainText, ENT_QUOTES | ENT_HTML5, 'UTF-8');
                $plainText = str_replace("\xc2\xa0", ' ', $plainText); // non-breaking space
                $plainText = preg_replace('/[ \t]+/', ' ', $plainText ?? '');
                $plainText = preg_replace('/[\r\n]{2,}/', "\n\n", $plainText ?? '');

                $text .= trim($plainText) . "\n\n";
            }

            libxml_clear_errors();
            return trim($text);
        }

        return '';
    }

    private function isGatewayEnabled($settings)
    {
        if (is_array($settings)) {
            return !empty($settings['llm_gateway_enabled']);
        }

        return !empty($settings->llm_gateway_enabled);
    }

    private function normalizeBaseUrl($baseUrl)
    {
        return rtrim(trim((string) $baseUrl), '/');
    }

    private function buildCompatibleApiUrl($baseUrl, $path)
    {
        $baseUrl = $this->normalizeBaseUrl($baseUrl);
        $path = '/' . ltrim((string) $path, '/');

        if (preg_match('#/v[0-9]+$#i', $baseUrl) && preg_match('#^/v[0-9]+(/.*)?$#i', $path, $matches)) {
            $path = !empty($matches[1]) ? $matches[1] : '';
        }

        return $baseUrl . $path;
    }

    private function getGenerationApiConfig($settings)
    {
        if ($this->isGatewayEnabled($settings)) {
            $baseUrl = $this->normalizeBaseUrl($settings->llm_gateway_base_url ?? '');

            return [
                'gateway_enabled' => true,
                'api_key' => $settings->llm_gateway_api_key ?? '',
                'endpoint' => $baseUrl ? $this->buildCompatibleApiUrl($baseUrl, '/v1/chat/completions') : '',
            ];
        }

        return [
            'gateway_enabled' => false,
            'api_key' => $settings->api_key ?? '',
            'endpoint' => $this->buildCompatibleApiUrl($this->defaultOpenAiBaseUrl, '/v1/responses'),
        ];
    }

    private function getEmbeddingApiConfig($settings)
    {
        if ($this->isGatewayEnabled($settings) && !empty($settings->llm_gateway_api_key) && !empty($settings->llm_gateway_base_url)) {
            return [
                'api_key' => $settings->llm_gateway_api_key,
                'endpoint' => $this->buildCompatibleApiUrl($settings->llm_gateway_base_url, '/v1/embeddings'),
                'model' => !empty($settings->llm_gateway_embedding_model) ? $settings->llm_gateway_embedding_model : 'openai/text-embedding-3-small',
                'gateway_enabled' => true,
            ];
        }

        if (!empty($settings->api_key)) {
            return [
                'api_key' => $settings->api_key,
                'endpoint' => $this->buildCompatibleApiUrl($this->defaultOpenAiBaseUrl, '/v1/embeddings'),
                'model' => 'text-embedding-3-small',
                'gateway_enabled' => false,
            ];
        }

        return [
            'api_key' => '',
            'endpoint' => $this->buildCompatibleApiUrl($this->defaultOpenAiBaseUrl, '/v1/embeddings'),
            'model' => 'text-embedding-3-small',
            'gateway_enabled' => false,
        ];
    }

    private function extractResponsesApiText(array $data)
    {
        if (!isset($data['output'])) {
            return 'Error: OpenAI API response missing "output" field. Full response: ' . json_encode($data);
        }
        if (!is_array($data['output'])) {
            return 'Error: OpenAI API "output" is not an array. Type: ' . gettype($data['output']);
        }
        if (empty($data['output'])) {
            return 'Error: OpenAI API returned empty output array.';
        }

        foreach ($data['output'] as $item) {
            if (
                isset($item['type'], $item['content'][0]['text']) &&
                $item['type'] === 'message' &&
                is_string($item['content'][0]['text'])
            ) {
                return trim($item['content'][0]['text'], "\n");
            }
        }

        $outputTypes = array_map(function($item) {
            return isset($item['type']) ? $item['type'] : 'unknown_type';
        }, $data['output']);

        return 'Error: OpenAI API response did not contain a valid message. Output types found: ' . json_encode($outputTypes);
    }

    private function extractChatCompletionsText(array $data)
    {
        if (empty($data['choices']) || !is_array($data['choices'])) {
            return '';
        }

        foreach ($data['choices'] as $choice) {
            $content = $choice['message']['content'] ?? null;
            if (is_string($content)) {
                return trim($content);
            }
            if (is_array($content)) {
                $parts = [];
                foreach ($content as $part) {
                    if (is_string($part)) {
                        $parts[] = $part;
                    } elseif (isset($part['text']) && is_string($part['text'])) {
                        $parts[] = $part['text'];
                    }
                }
                if (!empty($parts)) {
                    return trim(implode("\n", $parts));
                }
            }
        }

        return '';
    }

    private function sanitizePayloadForLog($payload)
    {
        if (!is_array($payload)) {
            return $payload;
        }

        $safe = $payload;
        if (isset($safe['input']) && is_string($safe['input'])) {
            $safe['input'] = mb_substr($safe['input'], 0, 500) . (mb_strlen($safe['input']) > 500 ? '...[truncated]' : '');
        }
        if (isset($safe['messages']) && is_array($safe['messages'])) {
            foreach ($safe['messages'] as $idx => $msg) {
                if (isset($msg['content']) && is_string($msg['content'])) {
                    $safe['messages'][$idx]['content'] = mb_substr($msg['content'], 0, 300) . (mb_strlen($msg['content']) > 300 ? '...[truncated]' : '');
                }
            }
        }

        return $safe;
    }

    private function buildApiErrorMessage($e, $context, array $meta = [])
    {
        $errorMessage = $e->getMessage();
        $statusCode = null;
        $body = '';
        $decoded = null;
        $rawErrorDetails = '';

        if (method_exists($e, 'getResponse') && $e->getResponse()) {
            $response = $e->getResponse();
            $statusCode = method_exists($response, 'getStatusCode') ? $response->getStatusCode() : null;
            $body = (string) $response->getBody();
            $decoded = json_decode($body, true);
            $parsed = $this->extractApiErrorFromBody($decoded);
            if (!empty($parsed)) {
                $errorMessage = $parsed;
                $rawErrorDetails = $parsed;
            }

            if (stripos($errorMessage, 'Provider returned error') !== false && !empty($body)) {
                $rawErrorDetails = $errorMessage . ' | Raw provider response: ' . mb_substr($body, 0, 1200);
            }
        }

        // Build user-friendly message based on error code
        $userMessage = $this->buildUserFacingErrorMessage($statusCode, $errorMessage);

        $logContext = array_merge($meta, [
            'status_code' => $statusCode,
            'exception_message' => $e->getMessage(),
            'raw_error' => $rawErrorDetails,
            'response_body_snippet' => !empty($body) ? mb_substr($body, 0, 2000) : null,
        ]);
        \Log::error('GPTPro API error [' . $context . ']: ' . $errorMessage, $logContext);

        return $userMessage;
    }

    private function buildUserFacingErrorMessage($statusCode, $rawMessage)
    {
        $normalizedRawMessage = mb_strtolower((string) $rawMessage);
        $details = $this->truncateUserFacingErrorDetails($rawMessage);

        if (
            strpos($normalizedRawMessage, 'curl error 28') !== false ||
            strpos($normalizedRawMessage, 'operation timed out') !== false ||
            strpos($normalizedRawMessage, 'timed out after') !== false
        ) {
            return 'The AI provider took too long to respond and the request timed out. Try again, reduce token usage, or increase the configured cURL timeout if this provider is consistently slow.' . (!empty($details) ? ' Details: ' . $details : '');
        }

        if (
            strpos($normalizedRawMessage, 'model not found') !== false ||
            strpos($normalizedRawMessage, 'no such model') !== false ||
            strpos($normalizedRawMessage, 'does not exist') !== false ||
            strpos($normalizedRawMessage, 'unknown model') !== false ||
            strpos($normalizedRawMessage, 'unsupported model') !== false
        ) {
            return 'The configured embedding model was not found on the AI provider. If gateway mode is enabled, make sure the provider supports openai/text-embedding-3-small.' . (!empty($details) ? ' Details: ' . $details : '');
        }

        if (empty($statusCode)) {
            return !empty($details) ? $details : 'An error occurred with the AI provider. Please try again.';
        }

        switch ($statusCode) {
            case 429:
                return 'Rate limited by provider (429), please try again in few minutes.' . (!empty($details) ? ' Details: ' . $details : '');
            case 401:
            case 403:
                return 'Invalid API credentials (401/403). Please verify your configuration.' . (!empty($details) ? ' Details: ' . $details : '');
            case 408:
                return 'The request timed out (408). Please try again.' . (!empty($details) ? ' Details: ' . $details : '');
            case 500:
            case 502:
            case 503:
            case 504:
                return 'The AI provider is experiencing issues (5xx). Please try again later.' . (!empty($details) ? ' Details: ' . $details : '');
            default:
                if (!empty($details)) {
                    return $details;
                }
                return 'An error occurred with the AI provider. Please try again.';
        }
    }

    private function truncateUserFacingErrorDetails($rawMessage, $limit = 220)
    {
        if (empty($rawMessage) || !is_string($rawMessage)) {
            return '';
        }

        $details = trim(preg_replace('/\s+/', ' ', $rawMessage));
        if ($details === '') {
            return '';
        }

        if (mb_strlen($details) > $limit) {
            return mb_substr($details, 0, $limit) . '...';
        }

        return $details;
    }

    private function extractApiErrorFromBody($decoded)
    {
        if (!is_array($decoded)) {
            return '';
        }

        $messages = [];

        if (!empty($decoded['error']['message']) && is_string($decoded['error']['message'])) {
            $messages[] = $decoded['error']['message'];
        }
        if (!empty($decoded['error']['details']) && is_string($decoded['error']['details'])) {
            $messages[] = $decoded['error']['details'];
        }
        if (!empty($decoded['error']['raw']) && is_string($decoded['error']['raw'])) {
            $messages[] = $decoded['error']['raw'];
        }
        if (!empty($decoded['error']['type']) && is_string($decoded['error']['type'])) {
            $messages[] = 'type=' . $decoded['error']['type'];
        }
        if (!empty($decoded['message']) && is_string($decoded['message'])) {
            $messages[] = $decoded['message'];
        }
        if (!empty($decoded['detail']) && is_string($decoded['detail'])) {
            $messages[] = $decoded['detail'];
        }
        if (!empty($decoded['provider_error']) && is_string($decoded['provider_error'])) {
            $messages[] = $decoded['provider_error'];
        }
        if (!empty($decoded['raw_error']) && is_string($decoded['raw_error'])) {
            $messages[] = $decoded['raw_error'];
        }
        if (!empty($decoded['errors'][0]['message']) && is_string($decoded['errors'][0]['message'])) {
            $messages[] = $decoded['errors'][0]['message'];
        }

        $messages = array_values(array_unique(array_filter($messages)));
        return !empty($messages) ? implode(' | ', $messages) : '';
    }

    /**
     * Generate and cache OpenAI embedding for a given text.
     * Returns the embedding vector (array) or null on failure.
     */
    private function getArticleEmbedding($text, $apiKey, $cacheKey, $cacheDays = 90, $endpoint = null, $model = 'text-embedding-3-small')
    {
        if (empty($text) || empty($apiKey)) return null;
        $embeddingCacheKey = $cacheKey . '_embedding';
        if (Cache::store('file')->has($embeddingCacheKey)) {
            // \Log::info('Embedding cache used! ', ['key' => $embeddingCacheKey]);
            return Cache::store('file')->get($embeddingCacheKey);
        }
        try {
            $this->lastEmbeddingError = null;
            $client = new \GuzzleHttp\Client();
            $response = $client->post($endpoint ?: $this->buildCompatibleApiUrl($this->defaultOpenAiBaseUrl, '/v1/embeddings'), [
                'timeout' => config('app.curl_timeout'),
                'connect_timeout' => config('app.curl_connect_timeout'),
                'proxy' => config('app.proxy'),
                'headers' => [
                    'Authorization' => 'Bearer ' . $apiKey,
                    'Content-Type' => 'application/json',
                ],
                'json' => [
                    'model' => $model,
                    'input' => mb_substr($text, 0, 8191), // OpenAI limit
                ],
            ]);
            $data = json_decode($response->getBody(), true);
            if (isset($data['data'][0]['embedding'])) {
                $embedding = $data['data'][0]['embedding'];
                Cache::store('file')->put($embeddingCacheKey, $embedding, now()->addDays($cacheDays));
                $embeddingIndexKey = 'gptpro_embedding_keys';
                $eKeys = Cache::store('file')->get($embeddingIndexKey, []);
                $eKeys[] = $embeddingCacheKey;
                Cache::store('file')->put($embeddingIndexKey, array_unique($eKeys), now()->addDays($cacheDays));
                // \Log::info('Adding index of embedding cache key for ' . $cacheDays . ' days.', ['key' => $embeddingCacheKey, 'all_keys' => $eKeys]);
                return $embedding;
            }
        } catch (\Exception $e) {
            $this->lastEmbeddingError = $this->buildApiErrorMessage($e, 'embedding', [
                'endpoint' => $endpoint ?: $this->buildCompatibleApiUrl($this->defaultOpenAiBaseUrl, '/v1/embeddings'),
                'cache_key' => $cacheKey,
                'model' => $model,
            ]);
            return null;
        }
        return null;
    }

    /**
     * Compute cosine similarity between two vectors.
     */
    private function cosineSimilarity($vecA, $vecB)
    {
        if (!is_array($vecA) || !is_array($vecB)) return 0.0;
        if (count($vecA) !== count($vecB)) return 0.0;
        $dot = 0.0;
        $normA = 0.0;
        $normB = 0.0;
        for ($i = 0; $i < count($vecA); $i++) {
            $dot += $vecA[$i] * $vecB[$i];
            $normA += $vecA[$i] * $vecA[$i];
            $normB += $vecB[$i] * $vecB[$i];
        }
        if ($normA == 0.0 || $normB == 0.0) return 0.0;
        return $dot / (sqrt($normA) * sqrt($normB));
    }

    /**
     * Handle AI Edit requests for text editing actions.
     */
    public function aiEdit(Request $request) {
        if (Auth::user() === null) {
            \Log::error('Unauthorized: ' . json_encode($request->all(), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
            return Response::json(["error" => "Unauthorized"], 401);
        }

        $mailbox_id = $request->get("mailbox_id");
        if (!$mailbox_id) {
            \Log::error('No Mailbox ID: ' . json_encode($request->all(), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
            return Response::json(['error' => 'Mailbox ID is required.'], 400);
        }

        $userQuery = $request->get('text');
        $keep_fssub_cache = now()->addDay();
        $settings = GPTSettings::findOrFail($mailbox_id);

        $licenseCheckedKey = 'gptpro_fssub_cachekey' . $settings->mailbox_id;
        if (!Cache::store('file')->has($licenseCheckedKey)) {
            $licenseKey = $settings->gptpro_license_key;
            if ($licenseKey) {
                $licRequest = new \Illuminate\Http\Request(['gptpro_license_key' => $licenseKey]);
                $result = $this->validateLicenseKey($settings->mailbox_id, $licRequest);
                $resultData = $result instanceof \Illuminate\Http\JsonResponse ? $result->getData(true) : [];
                if (empty($resultData['success'])) {
                    $answerText = $resultData['error'] ?? 'License validation failed';
                    return Response::json([
                        'query' => $userQuery ?? '',
                        'answer' => $answerText
                    ], 200);
                }
                \Log::info('[License key validated successfully]');
                Cache::store('file')->put($licenseCheckedKey, true, $keep_fssub_cache);
            } else {
                $answerText = 'License key is missing';
                return Response::json([
                    'query' => $userQuery ?? '',
                    'answer' => $answerText
                ], 200);
            }
        }

        $text = $request->input('text');
        $action = $request->input('action');

        $generationConfig = $this->getGenerationApiConfig($settings);
        if (empty($generationConfig['api_key'])) {
            return Response::json(['error' => 'API key not configured for the selected provider.'], 500);
        }
        
        $model = is_string($settings->model) ? $settings->model : (is_array($settings->model) ? reset($settings->model) : 'gpt-4-turbo');
        // \Log::info('[Starting AI Edit Request] - Action: ' . $action);

        // Map action to prompt
        switch ($action) {
            case 'fix_spelling':
                $instruction = "Correct any spelling and grammar mistakes in the following text, but do not change its meaning, send back only the corrected text, and keep line returns and paragraphs intact.";
                break;
            case 'longer':
                $instruction = "Expand and elaborate and send back only the following text making it longer and more detailed. Keep line returns and paragraphs intact as much as possible.";
                break;
            case 'shorter':
                $instruction = "Rewrite and send back only the following text to be shorter and more concise, keeping the main idea. Keep line returns and paragraphs intact as much as possible.";
                break;
            case 'friendlier':
                $instruction = "Rewrite and send back only the following text to sound more friendly and casual, without exclaimation marks. Keep line returns and paragraphs intact as much as possible.";
                break;
            case 'professional':
                $instruction = "Rewrite and send back only the following text to sound more professional and formal. Keep line returns and paragraphs intact as much as possible.";
                break;
            default:
                $instruction = "Polish and send back only the following text as appropriate. Keep line returns and paragraphs intact.";
        }

        $edited = '';
        $payload = [];
        $targetEndpoint = '';
        try {
            $client = new \GuzzleHttp\Client();

            if ($generationConfig['gateway_enabled']) {
                // Use chat/completions format for compatible gateways
                $payload = [
                    'model' => $model,
                    'messages' => [
                        [
                            'role' => 'system',
                            'content' => $instruction,
                        ],
                        [
                            'role' => 'user',
                            'content' => $text,
                        ],
                    ],
                    'max_tokens' => (integer) $settings->token_limit,
                ];
                $targetEndpoint = $generationConfig['endpoint'];
                $response = $client->post($generationConfig['endpoint'], [
                    'timeout' => config('app.curl_timeout'),
                    'connect_timeout' => config('app.curl_connect_timeout'),
                    'proxy' => config('app.proxy'),
                    'headers' => [
                        'Authorization' => 'Bearer ' . $generationConfig['api_key'],
                        'Content-Type' => 'application/json',
                    ],
                    'json' => $payload,
                ]);
                $data = json_decode($response->getBody(), true);
                $edited = $this->extractChatCompletionsText($data);
                if ($edited === '') {
                    $edited = 'Sorry, no AI response, try again?';
                }
            } else {
                // Use Responses API format for native OpenAI
                $payload = [
                    'model' => $model,
                    'instructions' => $instruction,
                    'input' => $text,
                    'max_output_tokens' => (integer) $settings->token_limit,
                ];
                $targetEndpoint = $generationConfig['endpoint'];
                $response = $client->post($generationConfig['endpoint'], [
                    'timeout' => config('app.curl_timeout'),
                    'connect_timeout' => config('app.curl_connect_timeout'),
                    'proxy' => config('app.proxy'),
                    'headers' => [
                        'Authorization' => 'Bearer ' . $generationConfig['api_key'],
                        'Content-Type' => 'application/json',
                    ],
                    'json' => $payload,
                ]);
                $data = json_decode($response->getBody(), true);
                $edited = $this->extractResponsesApiText($data);
                if ($edited === '' || strpos($edited, 'Error:') === 0) {
                    $edited = 'Sorry, no AI response, try again?';
                }
            }

        } catch (\Exception $e) {
            $edited = $this->buildApiErrorMessage($e, 'ai_edit', [
                'gateway_enabled' => !empty($generationConfig['gateway_enabled']),
                'endpoint' => $targetEndpoint,
                'payload' => $this->sanitizePayloadForLog($payload),
            ]);
        }
        
        return Response::json(['edited' => $edited], 200);
    }


    public function getAvailableModels(Request $request)
    {
        $gatewayEnabled = filter_var($request->input('llm_gateway_enabled', false), FILTER_VALIDATE_BOOLEAN);
        $apiKey = trim((string) $request->input('api_key', ''));
        $gatewayApiKey = trim((string) $request->input('llm_gateway_api_key', ''));
        $gatewayBaseUrl = $this->normalizeBaseUrl($request->input('llm_gateway_base_url', ''));

        if ($gatewayEnabled) {
            if (!$gatewayBaseUrl || !$gatewayApiKey) {
                return response()->json(['error' => 'Gateway base URL and API key are required'], 400);
            }
            $modelsEndpoint = $this->buildCompatibleApiUrl($gatewayBaseUrl, '/v1/models');
            $cacheKey = 'gateway_models_' . md5($modelsEndpoint . '|' . $gatewayApiKey);
            $requestApiKey = $gatewayApiKey;
        } else {
            if (!$apiKey) {
                return response()->json(['error' => 'API key is required'], 400);
            }
            $modelsEndpoint = $this->buildCompatibleApiUrl($this->defaultOpenAiBaseUrl, '/v1/models');
            $cacheKey = 'openai_models_' . md5($apiKey);
            $requestApiKey = $apiKey;
        }

        // Check if models are cached
        if (Cache::store('file')->has($cacheKey)) {
            return response()->json(['data' => Cache::store('file')->get($cacheKey)]);
        }

        try {
            $client = new \GuzzleHttp\Client();
            $response = $client->get($modelsEndpoint, [
                'timeout' => config('app.curl_timeout'),
                'connect_timeout' => config('app.curl_connect_timeout'),
                'proxy' => config('app.proxy'),
                'headers' => [
                    'Authorization' => 'Bearer ' . $requestApiKey,
                    'Accept' => 'application/json',
                ],
            ]);

            $models = json_decode($response->getBody(), true);

            $filteredModels = array_filter($models['data'] ?? [], function ($model) use ($gatewayEnabled) {
                if (empty($model['id'])) {
                    return false;
                }

                $modelId = strtolower($model['id']);
                $excludedModelTerms = ['search', 'transcribe', 'realtime', 'whisper', 'babbage', 'davinci', 'curie', 'text-to-speech', 'dall-e', '-audio', 'tts', 'embedding', 'moderation', 'image'];
                foreach ($excludedModelTerms as $excludedModelTerm) {
                    if (strpos($modelId, $excludedModelTerm) !== false) {
                        return false;
                    }
                }

                if ($gatewayEnabled) {
                    return true;
                }

                if (strpos($modelId, 'gpt-4o') !== false || strpos($modelId, 'gpt-4.5') !== false || strpos($modelId, 'gpt-4.1') !== false || strpos($modelId, 'gpt-5') !== false) {
                    return true;
                }

                if (preg_match('/(o[1-5]{1})/', $modelId)) {
                    return true;
                }

                if (strpos($modelId, 'gpt-3.5') !== false || strpos($modelId, 'gpt-4-') !== false) {
                    return false;
                }

                return false;
            });

            // Sort filtered models alphabetically by 'id'
            usort($filteredModels, function($a, $b) {
                return strcmp($a['id'], $b['id']);
            });

            // Cache filtered models for 10 minutes
            Cache::store('file')->put($cacheKey, $filteredModels, now()->addMinutes(10));

            return response()->json(['data' => $filteredModels]);
        } catch (\Exception $e) {
            $errorMessage = $this->buildApiErrorMessage($e, 'get_models', [
                'gateway_enabled' => $gatewayEnabled,
                'endpoint' => $modelsEndpoint,
            ]);
            return response()->json(['error' => $errorMessage], 500);
        }
    }

    public function answers(Request $request)
    {
        if (Auth::user() === null) return Response::json(["error" => "Unauthorized"], 401);
        $conversation = $request->query('conversation');
        $threads = Thread::where("conversation_id", $conversation)->get();
        $result = [];
        foreach ($threads as $thread) {
            if ($thread->chatgpt !== "{}" && $thread->chatgpt !== null) {
                $answers = [];
                $answers_text = json_decode($thread->chatgpt, true);
                if ($answers_text === null) continue;
                foreach ($answers_text as $answer_text) {
                    array_push($answers, $answer_text);
                }
                $answer = ["thread" => $thread->id, "answers" => $answers];
                array_push($result, $answer);
            }
        }
        return Response::json(["answers" => $result], 200);
    }

    public function checkIsEnabled(Request $request)
    {
        $settings = GPTSettings::find($request->query("mailbox"));
        if (empty($settings)) {
            return Response::json(['enabled' => false], 200);
        }
        return Response::json(['enabled' => $settings['enabled']], 200);
    }

    public function settings($mailbox_id)
    {
        if (Auth::user() === null) return Response::json(["error" => "Unauthorized"], 401);

        $mailbox = Mailbox::findOrFail($mailbox_id);

        // Fetch settings from DB
        $settings = GPTSettings::where('mailbox_id', $mailbox_id)->first();
        $settings = $settings ? $settings->toArray() : [];

        if (empty($settings)) {
            $settings['mailbox_id'] = $mailbox_id;
            $settings['enabled'] = false;
            $settings['api_key'] = "";
            $settings['llm_gateway_enabled'] = false;
            $settings['llm_gateway_base_url'] = "";
            $settings['llm_gateway_api_key'] = "";
            $settings['llm_gateway_embedding_model'] = 'openai/text-embedding-3-small';
            $settings['token_limit'] = "";
            $settings['start_message'] = "";
            $settings['responses_api_prompt'] = "";
            $settings['model'] = "";
            $settings['client_data_enabled'] = false;
            $settings['use_kb_articles'] = false;
            $settings['cache_article_days'] = 30;
            $settings['embedding_cache_days'] = 90;
            $settings['use_kb_articles'] = false;
            $settings['use_saved_replies'] = false;
        } else {
            if (!isset($settings['llm_gateway_enabled'])) {
                $settings['llm_gateway_enabled'] = false;
            }
            if (!isset($settings['llm_gateway_base_url'])) {
                $settings['llm_gateway_base_url'] = '';
            }
            if (!isset($settings['llm_gateway_api_key'])) {
                $settings['llm_gateway_api_key'] = '';
            }
            if (!isset($settings['llm_gateway_embedding_model']) || $settings['llm_gateway_embedding_model'] === '') {
                $settings['llm_gateway_embedding_model'] = 'openai/text-embedding-3-small';
            }
            if (!isset($settings['use_kb_articles'])) {
                $settings['use_kb_articles'] = false;
            }
            if (!isset($settings['use_saved_replies'])) {
                $settings['use_saved_replies'] = false;
            }
        }

        return view('freescoutgptpro::settings', [
            'mailbox'   => $mailbox,
            'settings'  => $settings
        ]);
    }

    public function saveSettings($mailbox_id, Request $request)
    {
        if (Auth::user() === null) return Response::json(["error" => "Unauthorized"], 401);

        $existingSettings = GPTSettings::where('mailbox_id', $mailbox_id)->first();
        $gatewayEnabled = $request->has('llm_gateway_enabled');

        GPTSettings::updateOrCreate(
            ['mailbox_id' => $mailbox_id],
            [
                'api_key' => $request->has('api_key') ? $request->get('api_key') : ($existingSettings->api_key ?? null),
                'llm_gateway_enabled' => $gatewayEnabled,
                'llm_gateway_base_url' => $request->has('llm_gateway_base_url') ? trim((string) $request->get('llm_gateway_base_url')) : ($existingSettings->llm_gateway_base_url ?? ''),
                'llm_gateway_api_key' => $request->has('llm_gateway_api_key') ? $request->get('llm_gateway_api_key') : ($existingSettings->llm_gateway_api_key ?? null),
                'llm_gateway_embedding_model' => $request->has('llm_gateway_embedding_model') ? trim((string) $request->get('llm_gateway_embedding_model')) : ($existingSettings->llm_gateway_embedding_model ?? 'openai/text-embedding-3-small'),
                'enabled' => isset($_POST['gpt_enabled']),
                'token_limit' => $request->get('token_limit'),
                'start_message' => $request->get('start_message'),
                'model' => $request->get('model'),
                'client_data_enabled' => isset($_POST['show_client_data_enabled']),
                'article_urls' => $request->get('article_urls'),
                'responses_api_prompt' => $request->get('responses_api_prompt'),
                'use_kb_articles' => isset($_POST['use_kb_articles']),
                'use_saved_replies' => isset($_POST['use_saved_replies']),
                'cache_article_days' => $request->get('cache_article_days', 30),
                'embedding_cache_days' => $request->get('embedding_cache_days', 90),
                'auto_generate' => $request->has('auto_generate'),
            ]
        );
        \Session::flash('flash_success_floating', __('Settings updated'));
        return redirect()->route('freescoutgptpro.settings', ['mailbox_id' => $mailbox_id]);
    }

    public function refreshSettingsSync($settings = null)
    {
        if (empty($settings)) {
            \Log::info('Settings is empty, exiting');
            return Response::json(["error" => __("Mailbox settings were not found.")], 404);
        }
        // \Log::info('Checking settings...');
        if (empty($settings->gptpro_license_key)) {
            \Log::error('Invalid settings error 1');
            return Response::json(["error" => __("Invalid settings check...")], 403);
        }
        if (!preg_match('/^[0-9a-f]{8}-?[0-9a-f]{4}-?4[0-9a-f]{3}-?[89ab][0-9a-f]{3}-?[0-9a-f]{12}$/i', $settings->gptpro_fs_uuid ?? '')) {
            \Log::error('Invalid settings error 2');
            return Response::json(["error" => __("Invalid settings check...")], 403);
        }
        if (!empty($settings->gptpro_license_expiration) && strtolower($settings->gptpro_license_expiration) !== 'lifetime') {
            try {
                $now = new \DateTime();
                $expiresAt = new \DateTime($settings->gptpro_license_expiration);
                if ($now > $expiresAt) {
                \Log::error('Invalid settings error 3');
                    return Response::json(["error" => __("Invalid settings check...")], 403);
                }
            } catch (\Exception $e) {
                \Log::error('Invalid settings exception: ' . $e->getMessage());
                return Response::json(["error" => __("Invalid settings check...")], 403);
            }
        }
        return null;
    }

    /**
     * Clear cache for articles or embeddings.
     */
    public function clearCache(Request $request)
    {
        if (Auth::user() === null) return Response::json(["error" => "Unauthorized"], 401);
        $type = $request->input('cache_type');
        $cleared = 0;
        $settings = GPTSettings::find($request->query("mailbox"));
        if ($cachePrep = $this->refreshSettingsSync($settings)) return $cachePrep;

        if ($type === 'article') {
            // Clear all tracked article cache keys using the correct store
            $keys = Cache::store('file')->get('gptpro_article_keys', []);
            foreach ($keys as $key) {
                Cache::store('file')->forget($key);
                $cleared++;
            }
            Cache::store('file')->forget('gptpro_article_keys');
            \Session::flash('flash_success_floating', __('Article cache cleared: :count entries removed', ['count' => $cleared]));
        } elseif ($type === 'embedding') {
            // Clear all tracked embedding cache keys using the correct store
            $keys = Cache::store('file')->get('gptpro_embedding_keys', []);
            foreach ($keys as $key) {
                Cache::store('file')->forget($key);
                $cleared++;
            }
            Cache::store('file')->forget('gptpro_embedding_keys');
            \Session::flash('flash_success_floating', __('Embeddings cache cleared: :count entries removed', ['count' => $cleared]));
        } else {
            return Response::json(["error" => "Invalid cache type"], 400);
        }
        return Response::json(["success" => true, "cleared" => $cleared]);
    }

    /**
     * Validate license key via Freemius API for SaaS product.
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function validateLicenseKey($mailbox_id, Request $request)
    {
        $license_key = $request->input('gptpro_license_key');
        $activate_new_license = false;
        $activationJustCompleted = false;
        // \Log::info("Debug Freemius license activation: " . $license_key);

        $mailbox = Mailbox::findOrFail($mailbox_id);

        if (!$license_key) {
            return response()->json(['success' => false, 'error' => 'License key is missing from submission.'], 400);
        }

        try {
            $settings = GPTSettings::where('mailbox_id', $mailbox_id)->first();

            if (!empty($settings) && !empty($settings->gptpro_license_key)) {
                // Check if the license key is already set
                if ($settings->gptpro_license_key !== $license_key) {
                    $activate_new_license = true;
                }
            }
            // Generate or reuse UUIDv4
            if (!empty($settings) && !empty($settings->gptpro_fs_uuid)) {
                $fs_uuid = $settings->gptpro_fs_uuid;
            } else {
                $bytes = random_bytes(16);
                $bytes[6] = chr((ord($bytes[6]) & 0x0f) | 0x40); // Version 4
                $bytes[8] = chr((ord($bytes[8]) & 0x3f) | 0x80); // Variant 10
                $fs_uuid = bin2hex($bytes);
            }

            // If install info doesn't exist or we're trying a new license key, activate
            if ($activate_new_license || empty($settings) || empty($settings->gptpro_install_id) || empty($settings->gptpro_install_api_token)) {
                 \Log::info("Initiating Freemius license activation");
                $curl = curl_init();
                $postData = [
                    'uid' => $fs_uuid,
                    'license_key' => $license_key,
                    'url' => request()->getHost(),
                    'title' => config('app.name')
                ];

                $fs_activation_endpoint = 'https://api.freemius.com/v1/products/19065/licenses/activate.json?uid=' . $fs_uuid . '&license_key=' . urlencode($license_key);
                curl_setopt_array($curl, [
                    CURLOPT_URL => $fs_activation_endpoint,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_CUSTOMREQUEST => "POST",
                    CURLOPT_POSTFIELDS => json_encode($postData),
                    CURLOPT_HTTPHEADER => [
                        'Content-Type: application/json'
                    ]
                ]);

                $responseData = curl_exec($curl);
                $statusCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
                $err = curl_error($curl);
                curl_close($curl);

                if ($err) {
                    \Log::error("Freemius API cURL Error: " . $err);
                    return response()->json(['success' => false, 'error' => 'Connection error: ' . $err], 500);
                }

                $response = json_decode($responseData);

                if (!is_object($response)) {
                    \Log::error('Freemius API returned invalid JSON response');
                    return response()->json(['success' => false, 'error' => 'Invalid API response'], 500);
                }

                if (!empty($response->error)) {
                    $error = $response->error->message ?? 'Unknown API error';
                    \Log::error('Freemius license activation error: ' . $error);
                    return response()->json(['success' => false, 'error' => $error], 400);
                }

                if ($statusCode !== 200) {
                    \Log::error('Freemius API returned non-200 status code: ' . $statusCode);
                    return response()->json(['success' => false, 'error' => 'API error: HTTP ' . $statusCode], 400);
                }

                if (!isset($response->install_id) || !isset($response->install_api_token)) {
                    \Log::error('Freemius API response missing required fields');
                    return response()->json(['success' => false, 'error' => 'Invalid API response: missing installation data'], 400);
                }

                // Save successful activation data
                GPTSettings::updateOrCreate(
                    ['mailbox_id' => $mailbox_id],
                    [
                        'gptpro_license_key' => $license_key,
                        'gptpro_fs_uuid' => $fs_uuid,
                        'gptpro_fs_user_id' => isset($response->user_id) ? (string) $response->user_id : null,
                        'gptpro_install_id' => $response->install_id,
                        'gptpro_install_api_token' => $response->install_api_token,
                    ]
                );
                $activationJustCompleted = true;
                \Session::flash('flash_success_floating', __('License activated and saved successfully.'));
                // return response()->json(['success' => true]);
            }
        } catch (\Exception $e) {
            \Log::error('Freemius license validation exception: ' . $e->getMessage());
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }

        try {
            // Then also: Validate existing installation to get expiration date
            // Fetch Saved settings
            $settings = GPTSettings::where('mailbox_id', $mailbox_id)->first();

            $install_id = !empty($settings) ? $settings->gptpro_install_id : '';
            $uuid       = !empty($settings) ? $settings->gptpro_fs_uuid : '';
            $license    = !empty($settings) ? $settings->gptpro_license_key : '';

            $fs_validate_endpoint = "https://api.freemius.com/v1/products/19065/installs/{$install_id}/license.json?uid={$uuid}&license_key=" . urlencode($license);

            $curl = curl_init();
            curl_setopt_array($curl, [
                CURLOPT_URL => $fs_validate_endpoint,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_CUSTOMREQUEST => "GET",
                CURLOPT_HTTPHEADER => [
                    'Authorization: Bearer ' . $settings->gptpro_install_api_token
                ]
            ]);

            $responseData = curl_exec($curl);
            $statusCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
            $err = curl_error($curl);
            curl_close($curl);

            if ($err) {
                \Log::error("Freemius API cURL Error during validation: " . $err);
                return response()->json(['success' => false, 'error' => 'Connection error: ' . $err], 500);
            }

            $response = json_decode($responseData);

            if (!is_object($response)) {
                \Log::error('Freemius API returned invalid JSON response during validation');
                if ($activationJustCompleted) {
                    \Log::warning('Freemius validation returned invalid JSON right after activation; keeping saved install data.');
                    return response()->json(['success' => true, 'warning' => 'License activated, but delayed validation response received. Please refresh in a minute.']);
                }
                return response()->json(['success' => false, 'error' => 'Invalid API response'], 500);
            }

            // Handle unauthorized or not found errors by triggering reactivation
            if ( $statusCode === 401 || $statusCode === 403 || $statusCode === 404 || (!empty($response->is_cancelled) && $response->is_cancelled === true) ) {
                if ($activationJustCompleted) {
                    \Log::warning('Freemius validation returned unauthorized/not found immediately after activation; keeping install data to avoid losing activation.');
                    return response()->json(['success' => true, 'warning' => 'License activated. Final validation may take a moment; please refresh shortly.']);
                }
                \Log::error('FreeScout GPT Pro License cancelled, not found, or unauthorized: clearing install ID data for reactivation');
                GPTSettings::updateOrCreate(
                    ['mailbox_id' => $mailbox_id],
                    [
                        'gptpro_install_id' => null,
                        'gptpro_fs_user_id' => null,
                        'gptpro_install_api_token' => null
                    ]
                );
                \Session::flash('flash_error_floating', __('License was cancelled or requires reactivation.'));
                return response()->json(['success' => false, 'error' => 'License was cancelled or requires reactivation, please retry.'], 401);
            }

            if (!empty($response->error)) {
                $error = $response->error->message ?? 'Unknown API error';
                \Log::error('Freemius installation validation error: ' . $error);
                if ($activationJustCompleted) {
                    return response()->json(['success' => true, 'warning' => 'License activated, but validation returned a temporary error: ' . $error]);
                }
                return response()->json(['success' => false, 'error' => $error], 400);
            }

            if (!empty($response->expiration)) {
                $now = new \DateTime();
                $expiresAt = new \DateTime($response->expiration);

                if ($now > $expiresAt) {
                    \Log::error('Freemius license has expired.', [
                        'mailbox_id' => $mailbox_id,
                        'expired_at' => $response->expiration,
                    ]);
                GPTSettings::updateOrCreate(
                    ['mailbox_id' => $mailbox_id],
                    [
                        'gptpro_install_id' => null,
                        'gptpro_fs_user_id' => null,
                        'gptpro_install_api_token' => null
                    ]
                );
                \Session::flash('flash_error_floating', __('License has expired. Please renew or activate a valid license.'));
                return response()->json(['success' => false, 'error' => 'License has expired. Please renew or activate a valid license.'], 401);
                }
            }

            if ($statusCode !== 200) {
                \Log::error('Freemius API returned non-200 status code during validation: ' . $statusCode);
                if ($activationJustCompleted) {
                    return response()->json(['success' => true, 'warning' => 'License activated. Validation returned HTTP ' . $statusCode . '; please refresh shortly.']);
                }
                return response()->json(['success' => false, 'error' => 'API error: HTTP ' . $statusCode], 400);
            }

            if (!isset($response->activated) || $response->activated < 1) {
                \Log::error('Freemius license is not active');
                if ($activationJustCompleted) {
                    return response()->json(['success' => true, 'warning' => 'License activation completed, but active status is delayed. Please refresh in a moment.']);
                }
                return response()->json(['success' => false, 'error' => 'License has not been actived yet? Retry activating the license or contact support.'], 400);
            }

            // Save successful refresh data
            GPTSettings::updateOrCreate(
                ['mailbox_id' => $mailbox_id],
                [
                    'gptpro_license_expiration' => $response->expiration ?? 'Lifetime',
                ]
            );

            // Commenting out flash because it runs on settings load now as well, once per day
            // Moved up above to run on Activation only
            // \Session::flash('flash_success_floating', __('License validated and saved successfully.'));
            return response()->json(['success' => true]);

        } catch (\Exception $e) {
            \Log::error('Freemius license validation exception: ' . $e->getMessage());
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    /**
     * Deactivate license via Freemius API for SaaS product.
     * @param $mailbox_id
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function deactivateLicense($mailbox_id, Request $request)
    {
        if (Auth::user() === null) {
            return response()->json(['success' => false, 'error' => 'Unauthorized'], 401);
        }

        try {
            $settings = GPTSettings::where('mailbox_id', $mailbox_id)->first();

            if (empty($settings) || empty($settings->gptpro_install_id) || empty($settings->gptpro_install_api_token)) {
                \Log::error('Freemius deactivation error: missing installation data');
                return response()->json(['success' => false, 'error' => 'No active license to deactivate.'], 400);
            }

            $install_id = (int) $settings->gptpro_install_id;
            $uuid = trim((string) $settings->gptpro_fs_uuid);
            $license = trim((string) $settings->gptpro_license_key);
            $installApiToken = trim((string) $settings->gptpro_install_api_token);

            // Primary deactivation endpoint (license-scoped, required by Freemius)
            $fs_deactivate_endpoint = 'https://api.freemius.com/v1/products/19065/licenses/deactivate.json';
            $deactivatePayload = [
                'uid' => $uuid,
                'install_id' => $install_id,
                'license_key' => $license,
            ];

            $curl = curl_init();
            curl_setopt_array($curl, [
                CURLOPT_URL => $fs_deactivate_endpoint,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => json_encode($deactivatePayload),
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_HTTPHEADER => [
                    'Accept: application/json',
                    'Content-Type: application/json'
                ]
            ]);

            $responseData = curl_exec($curl);
            $statusCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
            $err = curl_error($curl);
            curl_close($curl);

            if ($err) {
                \Log::error("Freemius API cURL Error during deactivation: " . $err);
                return response()->json(['success' => false, 'error' => 'Connection error: ' . $err], 500);
            }

            $response = json_decode($responseData);

            if ($statusCode !== 200) {
                $errorMsg = 'API error: HTTP ' . $statusCode;
                if (is_object($response) && !empty($response->error)) {
                    $errorMsg = $response->error->message ?? $errorMsg;
                }

                // Fallback: some Freemius accounts still expect install-scoped deactivation with bearer auth.
                if ($statusCode === 401 || $statusCode === 403 || $statusCode === 404) {
                    $fallbackDeactivateEndpoint = "https://api.freemius.com/v1/products/19065/installs/{$install_id}/deactivate.json?uid={$uuid}&license_key=" . urlencode($license);
                    $fallbackCurl = curl_init();
                    curl_setopt_array($fallbackCurl, [
                        CURLOPT_URL => $fallbackDeactivateEndpoint,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                        CURLOPT_HTTPHEADER => [
                            'Authorization: Bearer ' . $installApiToken,
                            'Accept: application/json',
                            'Content-Type: application/json'
                        ]
                    ]);

                    $fallbackResponseData = curl_exec($fallbackCurl);
                    $fallbackStatusCode = curl_getinfo($fallbackCurl, CURLINFO_HTTP_CODE);
                    $fallbackErr = curl_error($fallbackCurl);
                    curl_close($fallbackCurl);

                    if ($fallbackErr) {
                        \Log::error('Freemius fallback deactivation cURL error: ' . $fallbackErr);
                        return response()->json(['success' => false, 'error' => 'Connection error: ' . $fallbackErr], 500);
                    }

                    $fallbackResponse = json_decode($fallbackResponseData);
                    if ($fallbackStatusCode !== 200) {
                        $fallbackErrorMsg = 'API error: HTTP ' . $fallbackStatusCode;
                        if (is_object($fallbackResponse) && !empty($fallbackResponse->error)) {
                            $fallbackErrorMsg = $fallbackResponse->error->message ?? $fallbackErrorMsg;
                        }
                        \Log::error('Freemius API deactivation fallback error: ' . $fallbackErrorMsg);
                        return response()->json(['success' => false, 'error' => $fallbackErrorMsg], 400);
                    }
                } else {
                    \Log::error('Freemius API deactivation error: ' . $errorMsg);
                    return response()->json(['success' => false, 'error' => $errorMsg], 400);
                }
            }

            // Clear the license data from the database
            GPTSettings::updateOrCreate(
                ['mailbox_id' => $mailbox_id],
                [
                    'gptpro_license_key' => null,
                    'gptpro_fs_uuid' => null,
                    'gptpro_fs_user_id' => null,
                    'gptpro_install_id' => null,
                    'gptpro_install_api_token' => null,
                    'gptpro_license_expiration' => null,
                ]
            );

            \Log::info('Freemius license deactivated successfully for mailbox: ' . $mailbox_id);
            \Session::flash('flash_success_floating', __('License deactivated successfully. Page will reload.'));
            return response()->json(['success' => true]);

        } catch (\Exception $e) {
            \Log::error('Freemius license deactivation exception: ' . $e->getMessage());
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }
}
