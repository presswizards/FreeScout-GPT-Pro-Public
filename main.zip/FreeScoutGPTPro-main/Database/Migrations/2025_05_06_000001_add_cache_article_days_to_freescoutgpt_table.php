<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddCacheArticleDaysToFreescoutgptTable extends Migration {
    public function up()
    {
        Schema::table('freescoutgpt', function (Blueprint $table) {
            $table->integer('cache_article_days')->default(30)->after('use_kb_articles');
        });
    }

    public function down()
    {
        Schema::table('freescoutgpt', function (Blueprint $table) {
            $table->dropColumn('cache_article_days');
        });
    }
}
