<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddLlmGatewayFieldsToFreescoutgptTable extends Migration
{
    public function up()
    {
        Schema::table('freescoutgpt', function (Blueprint $table) {
            if (!Schema::hasColumn('freescoutgpt', 'llm_gateway_enabled')) {
                $table->boolean('llm_gateway_enabled')->default(false)->after('api_key');
            }

            if (!Schema::hasColumn('freescoutgpt', 'llm_gateway_base_url')) {
                $table->string('llm_gateway_base_url')->nullable()->after('llm_gateway_enabled');
            }

            if (!Schema::hasColumn('freescoutgpt', 'llm_gateway_api_key')) {
                $table->text('llm_gateway_api_key')->nullable()->after('llm_gateway_base_url');
            }
        });
    }

    public function down()
    {
        Schema::table('freescoutgpt', function (Blueprint $table) {
            if (Schema::hasColumn('freescoutgpt', 'llm_gateway_api_key')) {
                $table->dropColumn('llm_gateway_api_key');
            }

            if (Schema::hasColumn('freescoutgpt', 'llm_gateway_base_url')) {
                $table->dropColumn('llm_gateway_base_url');
            }

            if (Schema::hasColumn('freescoutgpt', 'llm_gateway_enabled')) {
                $table->dropColumn('llm_gateway_enabled');
            }
        });
    }
}