<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFreescoutgptTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('freescoutgpt', function (Blueprint $table) {
            $table->integer('mailbox_id');
            $table->boolean('enabled')->default(false);
            $table->string('api_key')->nullable();
            $table->integer('token_limit')->default(0);
            $table->string('start_message')->default('');
            $table->string('model')->default('');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('freescoutgpt');
    }
}
