<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddGptproLicenseExpirationToFreescoutgptTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('freescoutgpt', function (Blueprint $table) {
            if (!Schema::hasColumn('freescoutgpt', 'gptpro_license_expiration')) {
                $table->string('gptpro_license_expiration')->nullable()->after('gptpro_install_api_token');
            }
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('freescoutgpt', function (Blueprint $table) {
            if (Schema::hasColumn('freescoutgpt', 'gptpro_license_expiration')) {
                $table->dropColumn('gptpro_license_expiration');
            }
        });
    }
}
