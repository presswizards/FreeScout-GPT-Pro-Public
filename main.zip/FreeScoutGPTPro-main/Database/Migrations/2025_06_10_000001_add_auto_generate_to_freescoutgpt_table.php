<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddAutoGenerateToFreescoutgptTable extends Migration
{
    public function up()
    {
        Schema::table('freescoutgpt', function (Blueprint $table) {
            if (!Schema::hasColumn('freescoutgpt', 'auto_generate')) {
                $table->boolean('auto_generate')->default(false)->after('gptpro_license_expiration');
            }
        });
    }

    public function down()
    {
        Schema::table('freescoutgpt', function (Blueprint $table) {
            if (Schema::hasColumn('freescoutgpt', 'auto_generate')) {
                $table->dropColumn('auto_generate');
            }
        });
    }
}
