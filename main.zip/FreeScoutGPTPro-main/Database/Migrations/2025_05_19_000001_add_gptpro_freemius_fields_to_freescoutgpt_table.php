<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddGptproFreemiusFieldsToFreescoutgptTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('freescoutgpt', function (Blueprint $table) {
            if (Schema::hasColumn('freescoutgpt', 'license_key')) {
                $table->dropColumn('license_key');
            }
            if (!Schema::hasColumn('freescoutgpt', 'gptpro_license_key')) {
                $table->string('gptpro_license_key')->nullable();
            }
            if (!Schema::hasColumn('freescoutgpt', 'gptpro_fs_uuid')) {
                $table->string('gptpro_fs_uuid')->nullable()->after('gptpro_license_key');
            }
            if (!Schema::hasColumn('freescoutgpt', 'gptpro_install_id')) {
                $table->string('gptpro_install_id')->nullable()->after('gptpro_fs_uuid');
            }
            if (!Schema::hasColumn('freescoutgpt', 'gptpro_install_api_token')) {
                $table->string('gptpro_install_api_token')->nullable()->after('gptpro_install_id');
            }
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('freescoutgpt', function (Blueprint $table) {
            if (Schema::hasColumn('freescoutgpt', 'gptpro_license_key')) {
                $table->dropColumn('gptpro_license_key');
            }
            if (Schema::hasColumn('freescoutgpt', 'gptpro_fs_uuid')) {
                $table->dropColumn('gptpro_fs_uuid');
            }
            if (Schema::hasColumn('freescoutgpt', 'gptpro_install_id')) {
                $table->dropColumn('gptpro_install_id');
            }
            if (Schema::hasColumn('freescoutgpt', 'gptpro_install_api_token')) {
                $table->dropColumn('gptpro_install_api_token');
            }
        });
    }
}
