<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddEmbeddingCacheDaysToFreescoutgptTable extends Migration
{
    public function up()
    {
        Schema::table('freescoutgpt', function (Blueprint $table) {
            $table->integer('embedding_cache_days')->default(90);
        });
    }

    public function down()
    {
        Schema::table('freescoutgpt', function (Blueprint $table) {
            $table->dropColumn('embedding_cache_days');
        });
    }
}
