<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddGatewayEmbeddingModelToFreescoutgptTable extends Migration
{
    public function up()
    {
        Schema::table('freescoutgpt', function (Blueprint $table) {
            if (!Schema::hasColumn('freescoutgpt', 'llm_gateway_embedding_model')) {
                $table->string('llm_gateway_embedding_model')->nullable()->after('llm_gateway_api_key');
            }
        });
    }

    public function down()
    {
        Schema::table('freescoutgpt', function (Blueprint $table) {
            if (Schema::hasColumn('freescoutgpt', 'llm_gateway_embedding_model')) {
                $table->dropColumn('llm_gateway_embedding_model');
            }
        });
    }
}