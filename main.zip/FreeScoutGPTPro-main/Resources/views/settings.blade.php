@extends('layouts.app')

@section('title_full', 'FreeScout GPT Pro - ' . $mailbox->name)

@section('body_attrs')@parent data-mailbox_id="{{ $mailbox->id }}"@endsection

@section('sidebar')
    @include('partials/sidebar_menu_toggle')
    @include('mailboxes/sidebar_menu')
@endsection

@section('content')
    <div id="freescout-gpt-pro-container" data-mailbox-id="{{ $mailbox->id }}"></div>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <script src="{{ \Module::getPublicPath('freescoutgptpro') }}/js/settings.js"></script>
    <script type="text/javascript" src="https://checkout.freemius.com/js/v1/"></script>

    <div class="section-heading">
        FreeScout GPT Pro <i class="fa-solid fa-robot"></i> 
    </div>

    @if (empty($settings['gptpro_install_id']) || empty($settings['gptpro_license_key']))
        <div class="freemius-checkout" style="text-align: center;margin: 40px auto;width: 90%;max-width: 600px;">
            <h2>{{ __("Activate Your License") }}</h2>
            <p>{{ __("To get started, you'll need a valid license. You can click Buy Now to pick a plan and get your license key by email, or enter an existing license key below to activate.") }}</p>

            <button id="freemius-buy-btn"
                class="btn btn-success fs-buy-btn"
                style="font-size: 1.2em; padding: 12px 32px; margin-top: 20px;">
                {{ __("Buy Now") }}
            </button>
            <button id="freemius-trial-btn"
                class="btn btn-primary fs-trial-btn"
                style="font-size: 1.2em; padding: 12px 32px; margin-top: 20px; margin-left: 10px;">
                {{ __("Start 14 Day Free Trial") }}
            </button>
        </div>

        <div class="freemius-checkout" style="text-align: center; margin: 20px auto; width: 100%;">
            <form id="license-form" style="margin-bottom:20px;">
                <input type="text" id="gptpro_license_key" name="gptpro_license_key" placeholder="Enter License Key" style="font-size: 1.1em;width: 90%;padding:8px;max-width: 500px;" required />
                <button type="submit" class="btn btn-primary" style="padding: 6px 20px;margin: 10px;">{{ __("Activate License") }}</button>
                <div id="license-message" style="margin-top:10px;color:red;"></div>
            </form>
        </div>
    @else
        <div class="col-xs-12">
            <form class="form-horizontal margin-top margin-bottom" method="POST" action="">
                {{ csrf_field() }}

                <div class="form-group">
                    <label for="gpt_enabled" class="col-sm-3 control-label">{{ __("Enable AI Module") }}</label>

                    <div class="col-sm-6">
                        <i style="margin: 0 20px" class="glyphicon glyphicon-info-sign icon-info" data-toggle="popover" data-trigger="hover" data-html="true" data-placement="left" data-content="{{ __('Enable this module to turn on OpenAI features on this mailbox.') }}" data-original-title="" title=""></i>
                        <div class="controls">
                            <div class="onoffswitch-wrap">
                                <div class="onoffswitch">
                                    <input type="checkbox" name="gpt_enabled" id="gpt_enabled" class="onoffswitch-checkbox"
                                        {!! $settings['enabled'] ?? false ? "checked" : "" !!}
                                    >
                                    <label class="onoffswitch-label" for="gpt_enabled"></label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-sm-3 control-label">{{ __("OpenAI API Key") }}</label>

                    <div class="col-sm-6">
                        <input name="api_key" class="form-control" type="password" placeholder="sk-..." value="{{ $settings['api_key'] ?? '' }}" required />
                        <span class="help-block"><a target="_blank" href="https://platform.openai.com/api-keys">{{ __("Get Your API Key") }}</a></span>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-sm-3 control-label">{{ __("OpenAI Model") }}</label>

                    <div class="col-sm-6">
                    <i style="margin: 0 20px" class="glyphicon glyphicon-info-sign icon-info" data-toggle="popover" data-trigger="hover" data-html="true" data-placement="left" data-content="{{ __('Select the OpenAI model you\'d like to use. Compare models and pricing from the helpful links below.') }}" data-original-title="" title=""></i>
                       <select id="model" class="form-control input-sized" name="model" required data-saved-model="{{ old('model', $settings['model'] ?? '') }}">
                            <option value="">Fetching your API Key models...</option>
                       </select>
                    </div>
                </div>

                <div class="form-group margin-top">
                    <label class="col-sm-3 control-label">{{ __("Token Limit") }}</label>

                    <div class="col-sm-6">
                        <input name="token_limit" class="form-control" placeholder="4096" type="number" value="{{ $settings['token_limit'] ?? '4096' }}" required />
                        <span class="help-block">{{ __("Set a maximum number of tokens for the model's responses. A low limit may cause errors or truncation. The token limit determines the length of suggested responses and helps manage OpenAI's costs.") }} <a href="https://help.openai.com/en/articles/4936856-what-are-tokens-and-how-to-count-them" target="_blank">{{ __("What is a token limit?") }}</a></span>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-sm-3 control-label">{{ __("AI Training Prompt") }}</label>

                    <div class="col-sm-6">
                        <textarea rows="8" name="start_message" class="form-control" placeholder="Act like a professional customer support agent, and send a concise reply to the customer email." required>{{ $settings['start_message'] ?: "Act like a professional customer support agent, and send a concise reply to the customer email." }}</textarea>
                        <span class="help-block">{{ __("The system prompt guides AI in creating suggested customer responses. Edit this prompt to define the model's tone and purpose. Generate responses in a specific way to include common reply parts such as a greeting or signature.") }} <a href="https://help.openai.com/en/articles/10032626-prompt-engineering-best-practices-for-chatgpt" target="_blank">{{ __("How to create a GPT prompt?") }}</a></span>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-sm-3 control-label">{{ __("AI Content Prompt") }}</label>
                    <div class="col-sm-6">
                        <textarea rows="8" name="responses_api_prompt" class="form-control" placeholder="If relevant to the customer's message, refer to the articles included that best answers the user's question, and give detailed answers based on the content of the article, and provide the article URLs so they can reference it themselves as well. If the articles are not relevant, ignore the articles and URLs, and reply with a professional answer that addresses their specific concerns." required>{{ $settings['responses_api_prompt'] ?: "For a customer's message, and the articles included, find the articles that best answers the user's question. Give detailed answers based on the content of the article. Provide the article URLs so they can reference it further themselves as well." }}</textarea>
                        <span class="help-block">{{ __("The RAG Prompt specifies how AI uses your content (knowledge base, saved replies, or web pages) to suggest customer responses. Edit this prompt to guide the use of embedded content and explain how to incorporate URLs into answers effectively.") }} <a href="https://help.openai.com/en/articles/8868588-retrieval-augmented-generation-rag-and-semantic-search-for-gpts" target="_blank">{{ __("What's RAG Semantic Search Prompt?") }}</a></span>
                    </div>
                </div>

                <div class="form-group">
                    <label for="show_client_data_enabled" class="col-sm-3 control-label">{{ __("Share Client Name") }}</label>

                    <div class="col-sm-6" style="display: inline-flex;">
                        <i style="margin: 0 20px" class="glyphicon glyphicon-info-sign icon-info" data-toggle="popover" data-trigger="hover" data-html="true" data-placement="left" data-content="{{ __('Send the client\'s name to GPT to generate personalized responses.') }}" data-original-title="" title=""></i>
                        <div class="controls">
                            <div class="onoffswitch-wrap">
                                <div class="onoffswitch">
                                    <input type="checkbox" name="show_client_data_enabled" id="show_client_data_enabled" class="onoffswitch-checkbox"
                                        {!! $settings['client_data_enabled'] ?? false ? "checked" : "" !!}
                                    >
                                    <label class="onoffswitch-label" for="show_client_data_enabled"></label>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                <div class="form-group">
                    <label for="auto_generate" class="col-sm-3 control-label">{{ __("Enable Auto-Generate Answer") }}</label>
                    <div class="col-sm-6">
                        <i style="margin: 0 20px" class="glyphicon glyphicon-info-sign icon-info" data-toggle="popover" data-trigger="hover" data-html="true" data-placement="left" data-content="{{ __('Automatically generates a GPT answer upon clicking a message if none exists. Be mindful of AI model costs.') }}" data-original-title="" title=""></i>
                        <div class="onoffswitch-wrap">
                            <div class="onoffswitch">
                                <input type="checkbox" name="auto_generate" id="auto_generate" class="onoffswitch-checkbox" value="1" {{ (!empty($settings['auto_generate']) && $settings['auto_generate']) ? 'checked' : '' }}>
                                <label class="onoffswitch-label" for="auto_generate"></label>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="kb-widget-form">
                    <h3 class="subheader">{{ __("Your Content") }}</h3>
                </div>

                @if (\Module::find('Knowledge Base') && \Module::find('Knowledge Base')->enabled())
                <div class="form-group">
                    <label for="use_kb_articles" class="col-sm-3 control-label">{{ __("Use FreeScout Knowledge Base") }}</label>
                    <div class="col-sm-6">
                        <i style="margin: 0 20px" class="glyphicon glyphicon-info-sign icon-info" data-toggle="popover" data-trigger="hover" data-html="true" data-placement="left" data-content="{{ __('Enable GPT to use your FreeScout Knowledge Base to generate responses.') }}" data-original-title="" title=""></i>
                        <div class="controls">
                            <div class="onoffswitch-wrap">
                                <div class="onoffswitch">
                                    <input type="checkbox" name="use_kb_articles" id="use_kb_articles" class="onoffswitch-checkbox" {!! $settings['use_kb_articles'] ?? false ? "checked" : "" !!}>
                                    <label class="onoffswitch-label" for="use_kb_articles"></label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                @endif

                @if (\Module::find('Saved Replies') && \Module::find('Saved Replies')->enabled())
                <div class="form-group">
                    <label for="use_saved_replies" class="col-sm-3 control-label">{{ __("Use FreeScout Saved Replies") }}</label>
                    <div class="col-sm-6">
                        <i style="margin: 0 20px" class="glyphicon glyphicon-info-sign icon-info" data-toggle="popover" data-trigger="hover" data-html="true" data-placement="left" data-content="{{ __('Enable GPT to use your FreeScout Saved Replies to generate responses.') }}" data-original-title="" title=""></i>
                        <div class="controls">
                            <div class="onoffswitch-wrap">
                                <div class="onoffswitch">
                                    <input type="checkbox" name="use_saved_replies" id="use_saved_replies" class="onoffswitch-checkbox" {!! $settings['use_saved_replies'] ?? false ? "checked" : "" !!}>
                                    <label class="onoffswitch-label" for="use_saved_replies"></label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                @endif

                <div class="form-group" id="article-urls-group">
                    <label for="article_urls" class="col-sm-3 control-label">{{ __("Use Web Pages") }}</label>
                    <div class="col-sm-6">
                        <textarea rows="8" name="article_urls" class="form-control" placeholder="https://marketingsite.com/services/
https://pricingsite.com/prices/">{{ $settings['article_urls'] ?? '' }}</textarea>
                        <span class="help-block">{{ __("Enter one URL per web page, per line. Web pages will be fetched, cached, embedded and indexed to generate responses. It takes a few seconds to retrieve and cache each page when a response is generated for the first time. ") }}</span>
                    </div>
                </div>

                <div class="form-group">
                    <label for="cache_article_days" class="col-sm-3 control-label">{{ __("Cache Web Pages (days)") }}</label>
                    <div class="col-sm-6">
                        <input name="cache_article_days" id="cache_article_days" class="form-control" type="number" min="0" placeholder="30" value="{{ $settings['cache_article_days'] ?? '30' }}" />
                        <span class="help-block">{{ __("Choose how many days to cache web pages to improve GPT's speed and performance. Enter 0 to disable caching. If you change this setting, click ‘Clear Cache Now’ to reset the cache schedule.") }}</span>
                    </div>
                    <div class="col-sm-3">
                        <button type="button" class="btn btn-default clear-cache-btn" data-cache-type="article">
                            {{ __('Clear Cache Now') }}
                        </button>
                    </div>
                </div>

                <div class="form-group">
                    <label for="embedding_cache_days" class="col-sm-3 control-label">{{ __("Cache AI Index (days)") }}</label>
                    <div class="col-sm-6">
                        <input name="embedding_cache_days" id="embedding_cache_days" class="form-control" type="number" min="1" placeholder="90" value="{{ $settings['embedding_cache_days'] ?? '90' }}" />
                        <span class="help-block">{{ __("Choose how many days to cache embeds to improve GPT's speed and performance. The number must be 1 or higher. If you change this setting, click 'Clear Cache Now' to reset the cache schedule. Includes web pages and FreeScout Knowledge Base or Saved Replies.") }}</span>
                    </div>
                    <div class="col-sm-3">
                        <button type="button" class="btn btn-default clear-cache-btn" data-cache-type="embedding">
                            {{ __('Clear Cache Now') }}
                        </button>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-6 col-sm-offset-3">
                        <i style="margin: 11px 20px  0;" class="glyphicon glyphicon-info-sign icon-info" data-toggle="popover" data-trigger="hover" data-html="true" data-placement="left" data-content="{{ __('This rebuilds the cache to avoid the delay in using Generate Answer caused by expired or cleared cached entries being newly fetched or indexed') }}" data-original-title="" title=""></i>
                        <button type="button" class="btn btn-default" id="regenerate-embeds-btn" style="margin-top:10px;">
                            {{ __("Regenerate Web Pages and AI Index Cache Now") }}
                        </button>
                        <span id="regenerate-embeds-status" style="margin-left:10px;display:none;"></span>
                    </div>
                </div>

                <div class="form-group margin-top margin-bottom">
                    <div class="col-sm-6 col-sm-offset-2">
                        <button type="submit" class="btn btn-primary" style="font-size: 1.2em; padding: 10px 30px; margin-top: 20px;">
                            {{ __("Save") }}
                        </button>
                    </div>
                </div>
            </form>
            <h3 class="subheader">
                {{ __("Helpful Links") }}
            </h3>
            <p>
                <a href="https://platform.openai.com/usage" target="_blank">{{ __("Check Your ChatGPT Usage") }}</a>  <br>
                <a href="https://help.openai.com/en/articles/4936850-where-do-i-find-my-openai-api-key" target="_blank">{{ __("Where’s my API key?") }}</a>  <br>
                <a href="https://platform.openai.com/docs/models/compare" target="_blank">{{ __("Compare OpenAI Models") }}</a> <br>
                <a href="https://platform.openai.com/docs/pricing" target="_blank">{{ __("Model Pricing") }}</a>
            </p>

            <h3 class="subheader">
                {{ __("License Information") }}
            </h3>
            <div class="form-horizontal">
                <div class="form-group">
                    <div class="col-sm-3 col-md-5">
                        {{ __("License ID") }}: <strong>{{ $settings['gptpro_install_id'] ?? '' }}</strong><br>
                        {{ __("License Expiration") }}: <strong>{{ $settings['gptpro_license_expiration'] ?? '' }}</strong> <br>
                        <a href="https://5starplugins.com/user-dashboard/#!/login" target="_blank">{{ __("Manage Subscription") }}</a>
                        <span id="gptpro_license_key_data" data-gptpro-license-key="{{ $settings['gptpro_license_key'] ?? '' }}"></span>
                        <div id="license-message" style="margin-top:10px;color:red;font-size:1.2em;font-weight:700;"></div>
                    </div>
                    <div class="col-sm-6">
                        <button id="freemius-validate-btn" class="btn btn-default fs-validate-btn">{{ __("Refresh License") }}</button>
                        <button id="freemius-activate-btn" class="btn btn-default fs-validate-btn">{{ __("Activate New License") }}</button>
                    </div>
                </div>
                <div class="freemius-activate" style="display: none; text-align: center; margin: 20px auto; width: 100%;">
                    <form id="license-form" style="margin-bottom:20px;">
                        <input type="text" id="gptpro_license_key" name="gptpro_license_key" placeholder="Enter License Key" style="font-size: 1.1em;width: 90%;padding:8px;max-widt>
                        <button type="submit" class="btn btn-primary" style="padding: 6px 20px;margin: 10px;">{{ __("Activate License") }}</button>
                    </form>
                </div>
            </div>

            <h3 class="subheader">
                {{ __("Support") }}
            </h3>

            <p>
                <a href="https://support.5starplugins.com/help/670402815" target="_blank">{{ __("Contact Support") }}</a> <br>
                <a href="https://support.5starplugins.com/hc/670402815/162/install-freescout-gpt-pro-to-freescout?category_id=42" target="_blank">{{ __("Knowledge Base") }}</a> <br> 
                <a href="https://5starplugins.com/freescout-gpt-pro/" target="_blank">{{ __("5 Star Plugins") }}</a>
            </p>
        </div>
    @endif
@endsection

@section('body_bottom')
    @parent

@endsection
