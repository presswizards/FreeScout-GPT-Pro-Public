<?php

namespace Modules\FreeScoutGPTPro\Entities;

use Illuminate\Database\Eloquent\Model;

class GPTSettings extends Model
{
    protected $table = 'freescoutgpt';

    public $timestamps = false;

    protected $primaryKey = 'mailbox_id';

    public $incrementing = false;

    protected $fillable = [
        'mailbox_id',
        'api_key',
        'token_limit',
        'start_message',
        'enabled',
        'model',
        'client_data_enabled',
        'article_urls',
        'responses_api_prompt',
        'use_kb_articles',
        'cache_article_days',
        'embedding_cache_days',
        'use_saved_replies',
        // License and Freemius fields
        'gptpro_license_key',
        'gptpro_fs_uuid',
        'gptpro_install_id',
        'gptpro_install_api_token',
        'gptpro_license_expiration',
        'auto_generate',
    ];
}